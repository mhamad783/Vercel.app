import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export interface User {
  id: string;
  username: string;
  email: string;
  avatar?: string;
  isPremium: boolean;
  token?: string;
  mfaEnabled: boolean;
}

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  loginStep: 'credentials' | '2fa' | 'complete';
  tempCredentials: { email: string; password: string } | null;
  
  // Actions
  setLoginStep: (step: 'credentials' | '2fa' | 'complete') => void;
  setTempCredentials: (creds: { email: string; password: string } | null) => void;
  login: (user: User) => void;
  logout: () => void;
  updateUser: (updates: Partial<User>) => void;
  setToken: (token: string) => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      user: null,
      isAuthenticated: false,
      isLoading: false,
      loginStep: 'credentials',
      tempCredentials: null,

      setLoginStep: (step) => set({ loginStep: step }),
      setTempCredentials: (creds) => set({ tempCredentials: creds }),
      
      login: (user) => set({ 
        user, 
        isAuthenticated: true, 
        loginStep: 'complete',
        tempCredentials: null 
      }),
      
      logout: () => set({ 
        user: null, 
        isAuthenticated: false, 
        loginStep: 'credentials',
        tempCredentials: null 
      }),
      
      updateUser: (updates) => set((state) => ({
        user: state.user ? { ...state.user, ...updates } : null
      })),
      
      setToken: (token) => set((state) => ({
        user: state.user ? { ...state.user, token } : null
      })),
    }),
    {
      name: 'kaizen-auth',
      partialize: (state) => ({ 
        user: state.user, 
        isAuthenticated: state.isAuthenticated 
      }),
    }
  )
);
