import { create } from 'zustand';

export interface Operation {
  id: string;
  type: string;
  status: 'running' | 'completed' | 'cancelled' | 'error';
  progress: number;
  message: string;
  startedAt: Date;
}

interface FeatureState {
  // Operations
  operations: Operation[];
  activeOperations: Map<string, boolean>;
  
  // Snipers
  giveawaySniper: boolean;
  nitroSniper: boolean;
  
  // Quest
  questRunning: boolean;
  questProgress: number;
  
  // Clone
  cloneRunning: boolean;
  cloneProgress: number;
  cloneUsage: number;
  
  // Actions
  addOperation: (op: Operation) => void;
  updateOperation: (id: string, updates: Partial<Operation>) => void;
  removeOperation: (id: string) => void;
  cancelOperation: (id: string) => void;
  
  setGiveawaySniper: (enabled: boolean) => void;
  setNitroSniper: (enabled: boolean) => void;
  
  setQuestRunning: (running: boolean) => void;
  setQuestProgress: (progress: number) => void;
  
  setCloneRunning: (running: boolean) => void;
  setCloneProgress: (progress: number) => void;
  incrementCloneUsage: () => void;
}

export const useFeatureStore = create<FeatureState>((set) => ({
  operations: [],
  activeOperations: new Map(),
  
  giveawaySniper: false,
  nitroSniper: false,
  
  questRunning: false,
  questProgress: 0,
  
  cloneRunning: false,
  cloneProgress: 0,
  cloneUsage: 0,

  addOperation: (op) => set((state) => ({
    operations: [...state.operations, op],
    activeOperations: new Map(state.activeOperations).set(op.id, true)
  })),

  updateOperation: (id, updates) => set((state) => ({
    operations: state.operations.map(op => 
      op.id === id ? { ...op, ...updates } : op
    )
  })),

  removeOperation: (id) => set((state) => {
    const newMap = new Map(state.activeOperations);
    newMap.delete(id);
    return {
      operations: state.operations.filter(op => op.id !== id),
      activeOperations: newMap
    };
  }),

  cancelOperation: (id) => set((state) => {
    const newMap = new Map(state.activeOperations);
    newMap.set(id, false);
    return {
      operations: state.operations.map(op => 
        op.id === id ? { ...op, status: 'cancelled' } : op
      ),
      activeOperations: newMap
    };
  }),

  setGiveawaySniper: (enabled) => set({ giveawaySniper: enabled }),
  setNitroSniper: (enabled) => set({ nitroSniper: enabled }),
  
  setQuestRunning: (running) => set({ questRunning: running }),
  setQuestProgress: (progress) => set({ questProgress: progress }),
  
  setCloneRunning: (running) => set({ cloneRunning: running }),
  setCloneProgress: (progress) => set({ cloneProgress: progress }),
  incrementCloneUsage: () => set((state) => ({ cloneUsage: state.cloneUsage + 1 })),
}));
