import { useState } from 'react';
import { BrowserRouter, Routes, Route, Navigate, Link } from 'react-router-dom';
import { DiscordLogin } from '@/components/auth/DiscordLogin';
import { LoginForm } from '@/components/auth/LoginForm';
import { Sidebar } from '@/components/dashboard/Sidebar';
import { DashboardOverview } from '@/components/dashboard/DashboardOverview';
import { QuestAutomation } from '@/components/features/QuestAutomation';
import { ServerCloner } from '@/components/features/ServerCloner';
import { Snipers } from '@/components/features/Snipers';
import { TokenGenerator } from '@/components/features/TokenGenerator';
import { AccountStats } from '@/components/features/AccountStats';
import { MassUnfriend } from '@/components/features/MassUnfriend';
import { DMPurge } from '@/components/features/DMPurge';
import { AutoCall } from '@/components/features/AutoCall';
import { TokenSecurity } from '@/components/features/TokenSecurity';
import { RaidTools } from '@/components/features/RaidTools';
import { Utilities } from '@/components/features/Utilities';
import { SettingsPage } from '@/components/features/Settings';
import { useAuthStore } from '@/store/authStore';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Gamepad2, Key, ArrowRight } from 'lucide-react';

// Protected Route wrapper
function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { isAuthenticated } = useAuthStore();
  
  if (!isAuthenticated) {
    return <Navigate to="/" replace />;
  }
  
  return <>{children}</>;
}

// Login Choice Page
function LoginChoice() {
  const { isAuthenticated } = useAuthStore();
  
  if (isAuthenticated) {
    return <Navigate to="/dashboard" replace />;
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4 relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-slate-900 to-slate-800" />
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl" />
      <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl" />
      
      {/* Animated Grid */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute inset-0" style={{
          backgroundImage: 'linear-gradient(rgba(6, 182, 212, 0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(6, 182, 212, 0.1) 1px, transparent 1px)',
          backgroundSize: '50px 50px'
        }} />
      </div>

      <div className="w-full max-w-2xl relative z-10">
        <div className="text-center mb-8">
          <div className="mx-auto w-20 h-20 rounded-xl bg-gradient-to-br from-cyan-400 to-purple-600 flex items-center justify-center mb-4">
            <Gamepad2 className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-4xl font-bold gradient-text mb-2">Kaizen Dashboard</h1>
          <p className="text-slate-400">Choose your login method</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Discord Login Option */}
          <Link to="/login/discord">
            <Card className="glass-card hover-glow transition-all duration-300 cursor-pointer h-full">
              <CardContent className="p-6 flex flex-col items-center text-center">
                <div className="w-16 h-16 rounded-xl bg-[#5865F2] flex items-center justify-center mb-4">
                  <svg className="w-10 h-10 text-white" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028 14.09 14.09 0 0 0 1.226-1.994.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z"/>
                  </svg>
                </div>
                <h3 className="text-xl font-semibold text-white mb-2">Login with Discord</h3>
                <p className="text-slate-400 text-sm mb-4">
                  Enter your Discord email & password. We'll extract your token automatically.
                </p>
                <Button className="bg-[#5865F2] hover:bg-[#4752C4] w-full">
                  Login with Discord <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </CardContent>
            </Card>
          </Link>

          {/* Token Login Option */}
          <Link to="/login/token">
            <Card className="glass-card hover-glow transition-all duration-300 cursor-pointer h-full">
              <CardContent className="p-6 flex flex-col items-center text-center">
                <div className="w-16 h-16 rounded-xl bg-gradient-to-br from-cyan-500 to-purple-600 flex items-center justify-center mb-4">
                  <Key className="w-10 h-10 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-white mb-2">Login with Token</h3>
                <p className="text-slate-400 text-sm mb-4">
                  Already have a Discord token? Paste it directly to access the dashboard.
                </p>
                <Button variant="outline" className="border-cyan-500/30 text-cyan-400 hover:bg-cyan-500/10 w-full">
                  Use Token <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </CardContent>
            </Card>
          </Link>
        </div>

        <p className="text-center text-slate-600 text-sm mt-8">
          Created by <span className="text-cyan-400 font-semibold">kaizen</span>
        </p>
      </div>
    </div>
  );
}

// Dashboard Layout
function DashboardLayout() {
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  
  return (
    <div className="min-h-screen bg-slate-900">
      <Sidebar isCollapsed={isSidebarCollapsed} setIsCollapsed={setIsSidebarCollapsed} />
      <main 
        className={cn(
          "transition-all duration-300 min-h-screen",
          isSidebarCollapsed ? "ml-16" : "ml-64"
        )}
      >
        <div className="p-6 max-w-7xl mx-auto">
          <Routes>
            <Route index element={<DashboardOverview />} />
            <Route path="quest" element={<QuestAutomation />} />
            <Route path="clone" element={<ServerCloner />} />
            <Route path="snipers" element={<Snipers />} />
            <Route path="token-gen" element={<TokenGenerator />} />
            <Route path="stats" element={<AccountStats />} />
            <Route path="unfriend" element={<MassUnfriend />} />
            <Route path="purge" element={<DMPurge />} />
            <Route path="autocall" element={<AutoCall />} />
            <Route path="security" element={<TokenSecurity />} />
            <Route path="raid" element={<RaidTools />} />
            <Route path="utilities" element={<Utilities />} />
            <Route path="settings" element={<SettingsPage />} />
          </Routes>
        </div>
      </main>
    </div>
  );
}

function App() {
  const { isAuthenticated } = useAuthStore();

  return (
    <BrowserRouter>
      <Routes>
        <Route 
          path="/" 
          element={
            isAuthenticated ? <Navigate to="/dashboard" replace /> : <LoginChoice />
          } 
        />
        <Route 
          path="/login/discord" 
          element={
            isAuthenticated ? <Navigate to="/dashboard" replace /> : <DiscordLogin />
          } 
        />
        <Route 
          path="/login/token" 
          element={
            isAuthenticated ? <Navigate to="/dashboard" replace /> : <LoginForm />
          } 
        />
        <Route 
          path="/dashboard/*" 
          element={
            <ProtectedRoute>
              <DashboardLayout />
            </ProtectedRoute>
          } 
        />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
