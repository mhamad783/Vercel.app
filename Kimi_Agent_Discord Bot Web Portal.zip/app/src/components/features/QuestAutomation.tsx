import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Switch } from '@/components/ui/switch';
import { useAuthStore } from '@/store/authStore';
import { useFeatureStore } from '@/store/featureStore';
import {
  Target,
  Play,
  Square,
  Loader2,
  CheckCircle,
  AlertTriangle,
  Zap,
  Crown,
  Video,
  Gamepad2,
  Gift,
} from 'lucide-react';

interface Quest {
  id: string;
  name: string;
  type: 'video' | 'desktop';
  progress: number;
  status: 'pending' | 'running' | 'completed';
  reward: string;
}

export function QuestAutomation() {
  const { user } = useAuthStore();
  const { questRunning, questProgress, setQuestRunning, setQuestProgress, addOperation, updateOperation } = useFeatureStore();
  
  const [token, setToken] = useState('');
  const [showTokenInput, setShowTokenInput] = useState(true);
  const [isVerifying, setIsVerifying] = useState(false);
  const [error, setError] = useState('');
  const [autoClaim, setAutoClaim] = useState(true);
  const [quests, setQuests] = useState<Quest[]>([
    { id: '1', name: 'Watch Featured Video', type: 'video', progress: 0, status: 'pending', reward: '100 XP' },
    { id: '2', name: 'Play Desktop Game', type: 'desktop', progress: 0, status: 'pending', reward: '150 XP' },
    { id: '3', name: 'Watch Mobile Video', type: 'video', progress: 0, status: 'pending', reward: '75 XP' },
  ]);

  const isPremium = user?.isPremium;

  const handleVerifyToken = async () => {
    setError('');
    setIsVerifying(true);

    // Simulate token verification
    setTimeout(() => {
      setIsVerifying(false);
      if (token.length < 20) {
        setError('Invalid token format. Please provide a valid Discord user token.');
        return;
      }
      setShowTokenInput(false);
    }, 1500);
  };

  const handleStartQuests = async () => {
    setQuestRunning(true);
    setError('');

    const operationId = Math.random().toString(36).substr(2, 9);
    addOperation({
      id: operationId,
      type: 'Quest Automation',
      status: 'running',
      progress: 0,
      message: 'Starting quest automation...',
      startedAt: new Date(),
    });

    // Simulate quest automation
    let totalProgress = 0;
    const interval = setInterval(() => {
      totalProgress += isPremium ? 2 : 1;
      setQuestProgress(Math.min(totalProgress, 100));
      
      updateOperation(operationId, {
        progress: Math.min(totalProgress, 100),
        message: `Processing quests... ${Math.min(totalProgress, 100)}%`,
      });

      // Update individual quest progress
      setQuests(prev => prev.map((q, i) => {
        if (totalProgress > i * 33 && totalProgress < (i + 1) * 33) {
          return { ...q, status: 'running', progress: Math.min((totalProgress - i * 33) * 3, 100) };
        }
        if (totalProgress >= (i + 1) * 33) {
          return { ...q, status: 'completed', progress: 100 };
        }
        return q;
      }));

      if (totalProgress >= 100) {
        clearInterval(interval);
        setQuestRunning(false);
        updateOperation(operationId, {
          status: 'completed',
          progress: 100,
          message: 'All quests completed successfully!',
        });
      }
    }, isPremium ? 100 : 200);
  };

  const handleStopQuests = () => {
    setQuestRunning(false);
    setQuestProgress(0);
    setQuests(prev => prev.map(q => ({ ...q, status: 'pending', progress: 0 })));
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-white flex items-center gap-3">
            <Target className="w-8 h-8 text-cyan-400" />
            Quest Automation
          </h1>
          <p className="text-slate-400 mt-1">
            Automatically complete Discord quests and earn rewards
          </p>
        </div>
        <Badge className={isPremium 
          ? 'bg-gradient-to-r from-yellow-500 to-amber-500 text-white' 
          : 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30'
        }>
          {isPremium ? <><Crown className="w-4 h-4 mr-1" /> Premium Mode</> : 'Free Mode'}
        </Badge>
      </div>

      {/* Features Info */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="glass-card">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-cyan-500/20 flex items-center justify-center">
              <Video className="w-5 h-5 text-cyan-400" />
            </div>
            <div>
              <p className="text-white font-medium">Video Quests</p>
              <p className="text-slate-500 text-sm">Auto-watch videos</p>
            </div>
          </CardContent>
        </Card>
        <Card className="glass-card">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-purple-500/20 flex items-center justify-center">
              <Gamepad2 className="w-5 h-5 text-purple-400" />
            </div>
            <div>
              <p className="text-white font-medium">Desktop Games</p>
              <p className="text-slate-500 text-sm">Spoof game activity</p>
            </div>
          </CardContent>
        </Card>
        <Card className="glass-card">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-green-500/20 flex items-center justify-center">
              <Gift className="w-5 h-5 text-green-400" />
            </div>
            <div>
              <p className="text-white font-medium">Auto-Claim</p>
              <p className="text-slate-500 text-sm">{isPremium ? 'Premium: Auto-claim' : 'Manual claim only'}</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Token Input */}
      {showTokenInput ? (
        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="text-white">Authentication Required</CardTitle>
            <CardDescription className="text-slate-400">
              Please provide your Discord user token to start quest automation
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {error && (
              <Alert variant="destructive" className="bg-red-500/10 border-red-500/20">
                <AlertDescription className="text-red-400">{error}</AlertDescription>
              </Alert>
            )}
            <div className="space-y-2">
              <Label htmlFor="token" className="text-slate-300">Discord User Token</Label>
              <Input
                id="token"
                type="password"
                placeholder="Enter your Discord token..."
                value={token}
                onChange={(e) => setToken(e.target.value)}
                className="bg-slate-800/50 border-slate-700 text-white placeholder:text-slate-500"
              />
              <p className="text-xs text-slate-500">
                Your token is securely encrypted and never stored on our servers.
              </p>
            </div>
            <Button
              onClick={handleVerifyToken}
              disabled={isVerifying || !token}
              className="bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-400 hover:to-purple-500"
            >
              {isVerifying ? (
                <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Verifying...</>
              ) : (
                'Verify Token'
              )}
            </Button>
          </CardContent>
        </Card>
      ) : (
        <>
          {/* Control Panel */}
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="text-white">Control Panel</CardTitle>
              <CardDescription className="text-slate-400">
                Configure and start quest automation
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Settings */}
              <div className="flex flex-col md:flex-row md:items-center gap-4 p-4 rounded-lg bg-slate-800/50">
                <div className="flex items-center justify-between flex-1">
                  <div className="flex items-center gap-3">
                    <Gift className="w-5 h-5 text-cyan-400" />
                    <div>
                      <p className="text-white font-medium">Auto-Claim Rewards</p>
                      <p className="text-slate-500 text-sm">
                        {isPremium ? 'Automatically claim quest rewards' : 'Premium feature only'}
                      </p>
                    </div>
                  </div>
                  <Switch
                    checked={autoClaim}
                    onCheckedChange={setAutoClaim}
                    disabled={!isPremium}
                  />
                </div>
              </div>

              {/* Speed Info */}
              <div className="flex items-center gap-4 p-4 rounded-lg bg-slate-800/50">
                <Zap className={`w-5 h-5 ${isPremium ? 'text-yellow-400' : 'text-slate-400'}`} />
                <div>
                  <p className="text-white font-medium">
                    Speed: {isPremium ? '2x Faster (Premium)' : '1x (Free)'}
                  </p>
                  <p className="text-slate-500 text-sm">
                    {isPremium 
                      ? 'Parallel execution with 2x speed boost' 
                      : 'Sequential processing at normal speed'}
                  </p>
                </div>
              </div>

              {/* Progress */}
              {questRunning && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-white font-medium">Overall Progress</span>
                    <span className="text-cyan-400">{questProgress}%</span>
                  </div>
                  <Progress value={questProgress} className="h-3" />
                </div>
              )}

              {/* Action Buttons */}
              <div className="flex gap-3">
                {!questRunning ? (
                  <Button
                    onClick={handleStartQuests}
                    className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-400 hover:to-emerald-500"
                  >
                    <Play className="mr-2 h-4 w-4" />
                    Start Quest Automation
                  </Button>
                ) : (
                  <Button
                    onClick={handleStopQuests}
                    variant="destructive"
                  >
                    <Square className="mr-2 h-4 w-4" />
                    Stop Automation
                  </Button>
                )}
                <Button
                  variant="outline"
                  onClick={() => setShowTokenInput(true)}
                  className="border-slate-700 text-slate-300 hover:text-white"
                >
                  Change Token
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Quests List */}
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="text-white">Available Quests</CardTitle>
              <CardDescription className="text-slate-400">
                Quests will be automatically completed in sequence
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {quests.map((quest) => (
                  <div
                    key={quest.id}
                    className={`p-4 rounded-lg border transition-all duration-300 ${
                      quest.status === 'running'
                        ? 'bg-amber-500/10 border-amber-500/30'
                        : quest.status === 'completed'
                        ? 'bg-green-500/10 border-green-500/30'
                        : 'bg-slate-800/50 border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        {quest.type === 'video' ? (
                          <Video className="w-5 h-5 text-cyan-400" />
                        ) : (
                          <Gamepad2 className="w-5 h-5 text-purple-400" />
                        )}
                        <div>
                          <p className="text-white font-medium">{quest.name}</p>
                          <p className="text-slate-500 text-sm">Reward: {quest.reward}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        {quest.status === 'running' && (
                          <Loader2 className="w-5 h-5 text-amber-400 animate-spin" />
                        )}
                        {quest.status === 'completed' && (
                          <CheckCircle className="w-5 h-5 text-green-400" />
                        )}
                        <Badge
                          variant={quest.status === 'completed' ? 'default' : 'outline'}
                          className={
                            quest.status === 'completed'
                              ? 'bg-green-500/20 text-green-400 border-green-500/30'
                              : quest.status === 'running'
                              ? 'bg-amber-500/20 text-amber-400 border-amber-500/30'
                              : 'border-slate-600 text-slate-400'
                          }
                        >
                          {quest.status.charAt(0).toUpperCase() + quest.status.slice(1)}
                        </Badge>
                      </div>
                    </div>
                    {quest.status === 'running' && (
                      <div className="mt-3">
                        <Progress value={quest.progress} className="h-2" />
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Disclaimer */}
          <Alert className="bg-amber-500/10 border-amber-500/20">
            <AlertTriangle className="w-5 h-5 text-amber-400" />
            <AlertDescription className="text-amber-200">
              <strong>Disclaimer:</strong> This tool uses selfbot technology which violates Discord's Terms of Service. 
              Account bans are possible. Use at your own risk. We are NOT responsible for any consequences.
            </AlertDescription>
          </Alert>
        </>
      )}
    </div>
  );
}
