import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Zap,
  RefreshCw,
  Image,
  Copy,
  Play,
  Square,
  Loader2,
  Plus,
  X,
  Clock,
} from 'lucide-react';

interface Status {
  id: string;
  text: string;
}

export function Utilities() {
  const [token, setToken] = useState('');
  const [showTokenInput, setShowTokenInput] = useState(true);
  const [isVerifying, setIsVerifying] = useState(false);
  const [error, setError] = useState('');
  
  // Status Rotator
  const [statuses, setStatuses] = useState<Status[]>([
    { id: '1', text: 'Gaming' },
    { id: '2', text: 'Chilling' },
    { id: '3', text: 'AFK' },
  ]);
  const [newStatus, setNewStatus] = useState('');
  const [rotationInterval, setRotationInterval] = useState(30);
  const [rotatorRunning, setRotatorRunning] = useState(false);
  const [currentStatus, setCurrentStatus] = useState('');
  const [rotatorIntervalId, setRotatorIntervalId] = useState<ReturnType<typeof setInterval> | null>(null);

  // Avatar Stealer
  const [targetUserId, setTargetUserId] = useState('');
  const [isStealing, setIsStealing] = useState(false);

  // Profile Cloner
  const [cloneTargetId, setCloneTargetId] = useState('');
  const [isCloning, setIsCloning] = useState(false);
  const [cloneProgress, setCloneProgress] = useState(0);

  const handleVerifyToken = async () => {
    setError('');
    setIsVerifying(true);

    setTimeout(() => {
      setIsVerifying(false);
      if (token.length < 20) {
        setError('Invalid token format');
        return;
      }
      setShowTokenInput(false);
    }, 1500);
  };

  const handleAddStatus = () => {
    if (!newStatus.trim()) return;
    setStatuses([...statuses, { id: Math.random().toString(36).substr(2, 9), text: newStatus }]);
    setNewStatus('');
  };

  const handleRemoveStatus = (id: string) => {
    setStatuses(statuses.filter(s => s.id !== id));
  };

  const handleStartRotator = () => {
    setRotatorRunning(true);
    let index = 0;
    setCurrentStatus(statuses[0]?.text || '');
    
    const interval = setInterval(() => {
      index = (index + 1) % statuses.length;
      setCurrentStatus(statuses[index]?.text || '');
    }, rotationInterval * 1000);

    setRotatorIntervalId(interval);

    // Stop after 5 minutes for demo
    setTimeout(() => {
      clearInterval(interval);
      setRotatorRunning(false);
      setCurrentStatus('');
      setRotatorIntervalId(null);
    }, 300000);
  };

  const handleStopRotator = () => {
    if (rotatorIntervalId) {
      clearInterval(rotatorIntervalId);
      setRotatorIntervalId(null);
    }
    setRotatorRunning(false);
    setCurrentStatus('');
  };

  const handleStealAvatar = () => {
    if (!targetUserId) return;
    setIsStealing(true);
    setTimeout(() => {
      setIsStealing(false);
      setTargetUserId('');
    }, 2000);
  };

  const handleCloneProfile = () => {
    if (!cloneTargetId) return;
    setIsCloning(true);
    setCloneProgress(0);
    
    const interval = setInterval(() => {
      setCloneProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsCloning(false);
          return 100;
        }
        return prev + 10;
      });
    }, 300);
  };

  if (showTokenInput) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-white flex items-center gap-3">
            <Zap className="w-8 h-8 text-cyan-400" />
            Utilities
          </h1>
          <p className="text-slate-400 mt-1">
            Status rotator, avatar stealer, and profile cloner
          </p>
        </div>

        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="text-white">Authentication Required</CardTitle>
            <CardDescription className="text-slate-400">
              Please provide your Discord user token
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {error && (
              <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/20 text-red-400">
                {error}
              </div>
            )}
            <div className="space-y-2">
              <Label htmlFor="token" className="text-slate-300">Discord User Token</Label>
              <Input
                id="token"
                type="password"
                placeholder="Enter your Discord token..."
                value={token}
                onChange={(e) => setToken(e.target.value)}
                className="bg-slate-800/50 border-slate-700 text-white placeholder:text-slate-500"
              />
            </div>
            <Button
              onClick={handleVerifyToken}
              disabled={isVerifying || !token}
              className="bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-400 hover:to-purple-500"
            >
              {isVerifying ? (
                <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Verifying...</>
              ) : (
                'Verify Token'
              )}
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-white flex items-center gap-3">
          <Zap className="w-8 h-8 text-cyan-400" />
          Utilities
        </h1>
        <p className="text-slate-400 mt-1">
          Status rotator, avatar stealer, and profile cloner
        </p>
      </div>

      {/* Tools */}
      <Tabs defaultValue="status" className="w-full">
        <TabsList className="bg-slate-800/50">
          <TabsTrigger value="status" className="data-[state=active]:bg-cyan-500/20 data-[state=active]:text-cyan-400">
            <RefreshCw className="w-4 h-4 mr-2" />
            Status Rotator
          </TabsTrigger>
          <TabsTrigger value="avatar" className="data-[state=active]:bg-cyan-500/20 data-[state=active]:text-cyan-400">
            <Image className="w-4 h-4 mr-2" />
            Avatar Stealer
          </TabsTrigger>
          <TabsTrigger value="profile" className="data-[state=active]:bg-cyan-500/20 data-[state=active]:text-cyan-400">
            <Copy className="w-4 h-4 mr-2" />
            Profile Cloner
          </TabsTrigger>
        </TabsList>

        <TabsContent value="status" className="mt-4">
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="text-white">Status Rotator</CardTitle>
              <CardDescription className="text-slate-400">
                Automatically rotate your Discord status
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Status List */}
              <div className="space-y-2">
                <Label className="text-slate-300">Statuses</Label>
                <div className="flex flex-wrap gap-2">
                  {statuses.map((status) => (
                    <Badge
                      key={status.id}
                      variant="secondary"
                      className="bg-slate-700/50 text-slate-300 hover:bg-slate-700 cursor-pointer group"
                    >
                      {status.text}
                      <X
                        className="w-3 h-3 ml-1 opacity-0 group-hover:opacity-100 transition-opacity"
                        onClick={() => handleRemoveStatus(status.id)}
                      />
                    </Badge>
                  ))}
                </div>
                <div className="flex gap-2">
                  <Input
                    placeholder="Add status..."
                    value={newStatus}
                    onChange={(e) => setNewStatus(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleAddStatus()}
                    className="bg-slate-800/50 border-slate-700 text-white placeholder:text-slate-500"
                  />
                  <Button onClick={handleAddStatus} variant="secondary">
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              {/* Interval */}
              <div className="space-y-2">
                <Label htmlFor="interval" className="text-slate-300 flex items-center gap-2">
                  <Clock className="w-4 h-4" />
                  Rotation Interval (seconds)
                </Label>
                <Input
                  id="interval"
                  type="number"
                  value={rotationInterval}
                  onChange={(e) => setRotationInterval(Number(e.target.value))}
                  min={5}
                  className="bg-slate-800/50 border-slate-700 text-white placeholder:text-slate-500"
                />
              </div>

              {/* Current Status */}
              {rotatorRunning && currentStatus && (
                <div className="p-3 rounded-lg bg-cyan-500/10 border border-cyan-500/30">
                  <p className="text-slate-400 text-sm">Current Status</p>
                  <p className="text-cyan-400 font-medium">{currentStatus}</p>
                </div>
              )}

              {/* Controls */}
              <div className="flex gap-3">
                {!rotatorRunning ? (
                  <Button onClick={handleStartRotator} className="bg-green-500 hover:bg-green-600">
                    <Play className="mr-2 h-4 w-4" />
                    Start Rotator
                  </Button>
                ) : (
                  <Button onClick={handleStopRotator} variant="outline">
                    <Square className="mr-2 h-4 w-4" />
                    Stop
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="avatar" className="mt-4">
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="text-white">Avatar Stealer</CardTitle>
              <CardDescription className="text-slate-400">
                Copy another user's avatar to your profile
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="targetUser" className="text-slate-300">Target User ID</Label>
                <Input
                  id="targetUser"
                  placeholder="1234567890123456789"
                  value={targetUserId}
                  onChange={(e) => setTargetUserId(e.target.value)}
                  className="bg-slate-800/50 border-slate-700 text-white placeholder:text-slate-500"
                />
              </div>
              <Button
                onClick={handleStealAvatar}
                disabled={isStealing || !targetUserId}
                className="bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-400 hover:to-pink-500"
              >
                {isStealing ? (
                  <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Stealing...</>
                ) : (
                  <><Image className="mr-2 h-4 w-4" /> Steal Avatar</>
                )}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="profile" className="mt-4">
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="text-white">Profile Cloner</CardTitle>
              <CardDescription className="text-slate-400">
                Clone another user's entire profile (avatar, banner, bio, display name)
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="cloneTarget" className="text-slate-300">Target User ID</Label>
                <Input
                  id="cloneTarget"
                  placeholder="1234567890123456789"
                  value={cloneTargetId}
                  onChange={(e) => setCloneTargetId(e.target.value)}
                  className="bg-slate-800/50 border-slate-700 text-white placeholder:text-slate-500"
                />
              </div>

              {isCloning && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-white">Cloning...</span>
                    <span className="text-cyan-400">{cloneProgress}%</span>
                  </div>
                  <div className="h-2 bg-slate-700 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-cyan-500 to-purple-600 transition-all duration-300"
                      style={{ width: `${cloneProgress}%` }}
                    />
                  </div>
                </div>
              )}

              <Button
                onClick={handleCloneProfile}
                disabled={isCloning || !cloneTargetId}
                className="bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-400 hover:to-purple-500"
              >
                {isCloning ? (
                  <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Cloning...</>
                ) : (
                  <><Copy className="mr-2 h-4 w-4" /> Clone Profile</>
                )}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
