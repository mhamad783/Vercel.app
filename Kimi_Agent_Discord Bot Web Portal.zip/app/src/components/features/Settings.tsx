import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { useAuthStore } from '@/store/authStore';
import {
  Settings,
  User,
  Mail,
  Shield,
  Bell,
  Moon,
  Globe,
  Crown,
  CheckCircle,
  AlertTriangle,
  Save,
  Loader2,
} from 'lucide-react';

export function SettingsPage() {
  const { user } = useAuthStore();
  const [isSaving, setIsSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  
  const [settings, setSettings] = useState({
    email: user?.email || '',
    notifications: true,
    darkMode: true,
    language: 'en',
    autoStart: false,
    compactMode: false,
  });

  const handleSave = () => {
    setIsSaving(true);
    setTimeout(() => {
      setIsSaving(false);
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    }, 1000);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-white flex items-center gap-3">
          <Settings className="w-8 h-8 text-cyan-400" />
          Settings
        </h1>
        <p className="text-slate-400 mt-1">
          Manage your account and application settings
        </p>
      </div>

      {/* Account Settings */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <User className="w-5 h-5" />
            Account Settings
          </CardTitle>
          <CardDescription className="text-slate-400">
            Manage your account information
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="username" className="text-slate-300">Username</Label>
              <Input
                id="username"
                value={user?.username}
                disabled
                className="bg-slate-800/50 border-slate-700 text-slate-400"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email" className="text-slate-300 flex items-center gap-2">
                <Mail className="w-4 h-4" />
                Email
              </Label>
              <Input
                id="email"
                type="email"
                value={settings.email}
                onChange={(e) => setSettings({ ...settings, email: e.target.value })}
                className="bg-slate-800/50 border-slate-700 text-white"
              />
            </div>
          </div>

          <div className="flex items-center justify-between p-4 rounded-lg bg-slate-800/50">
            <div className="flex items-center gap-3">
              <Shield className="w-5 h-5 text-green-400" />
              <div>
                <p className="text-white font-medium">Two-Factor Authentication</p>
                <p className="text-slate-500 text-sm">Secure your account with 2FA</p>
              </div>
            </div>
            <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
              <CheckCircle className="w-3 h-3 mr-1" />
              Enabled
            </Badge>
          </div>

          <div className="flex items-center justify-between p-4 rounded-lg bg-slate-800/50">
            <div className="flex items-center gap-3">
              <Crown className="w-5 h-5 text-yellow-400" />
              <div>
                <p className="text-white font-medium">Premium Status</p>
                <p className="text-slate-500 text-sm">
                  {user?.isPremium ? 'Your premium subscription is active' : 'Upgrade to unlock all features'}
                </p>
              </div>
            </div>
            {user?.isPremium ? (
              <Badge className="bg-gradient-to-r from-yellow-500 to-amber-500 text-white">
                <Crown className="w-3 h-3 mr-1" />
                Active
              </Badge>
            ) : (
              <Button size="sm" className="bg-gradient-to-r from-yellow-500 to-amber-500 hover:from-yellow-400 hover:to-amber-400">
                <Crown className="w-4 h-4 mr-1" />
                Upgrade
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Application Settings */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Settings className="w-5 h-5" />
            Application Settings
          </CardTitle>
          <CardDescription className="text-slate-400">
            Customize your dashboard experience
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between p-4 rounded-lg bg-slate-800/50">
            <div className="flex items-center gap-3">
              <Bell className="w-5 h-5 text-cyan-400" />
              <div>
                <p className="text-white font-medium">Notifications</p>
                <p className="text-slate-500 text-sm">Receive alerts for completed operations</p>
              </div>
            </div>
            <Switch
              checked={settings.notifications}
              onCheckedChange={(v) => setSettings({ ...settings, notifications: v })}
            />
          </div>

          <div className="flex items-center justify-between p-4 rounded-lg bg-slate-800/50">
            <div className="flex items-center gap-3">
              <Moon className="w-5 h-5 text-purple-400" />
              <div>
                <p className="text-white font-medium">Dark Mode</p>
                <p className="text-slate-500 text-sm">Use dark theme (always enabled)</p>
              </div>
            </div>
            <Switch checked={true} disabled />
          </div>

          <div className="flex items-center justify-between p-4 rounded-lg bg-slate-800/50">
            <div className="flex items-center gap-3">
              <Globe className="w-5 h-5 text-green-400" />
              <div>
                <p className="text-white font-medium">Language</p>
                <p className="text-slate-500 text-sm">Select your preferred language</p>
              </div>
            </div>
            <select
              value={settings.language}
              onChange={(e) => setSettings({ ...settings, language: e.target.value })}
              className="bg-slate-700 border-slate-600 text-white rounded-lg px-3 py-2"
            >
              <option value="en">English</option>
              <option value="es">Spanish</option>
              <option value="fr">French</option>
              <option value="de">German</option>
            </select>
          </div>

          <div className="flex items-center justify-between p-4 rounded-lg bg-slate-800/50">
            <div className="flex items-center gap-3">
              <Settings className="w-5 h-5 text-amber-400" />
              <div>
                <p className="text-white font-medium">Auto-Start Operations</p>
                <p className="text-slate-500 text-sm">Automatically resume operations on login</p>
              </div>
            </div>
            <Switch
              checked={settings.autoStart}
              onCheckedChange={(v) => setSettings({ ...settings, autoStart: v })}
            />
          </div>
        </CardContent>
      </Card>

      {/* Danger Zone */}
      <Card className="glass-card border-red-500/30">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-red-400" />
            Danger Zone
          </CardTitle>
          <CardDescription className="text-slate-400">
            Irreversible account actions
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between p-4 rounded-lg bg-red-500/10 border border-red-500/20">
            <div>
              <p className="text-white font-medium">Delete Account Data</p>
              <p className="text-slate-500 text-sm">Permanently delete all your saved data</p>
            </div>
            <Button variant="destructive" size="sm">
              Delete
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Save Button */}
      <div className="flex justify-end">
        <Button
          onClick={handleSave}
          disabled={isSaving}
          className="bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-400 hover:to-purple-500"
        >
          {isSaving ? (
            <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Saving...</>
          ) : saved ? (
            <><CheckCircle className="mr-2 h-4 w-4" /> Saved!</>
          ) : (
            <><Save className="mr-2 h-4 w-4" /> Save Changes</>
          )}
        </Button>
      </div>
    </div>
  );
}
