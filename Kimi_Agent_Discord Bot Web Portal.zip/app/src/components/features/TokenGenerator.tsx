import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useAuthStore } from '@/store/authStore';
import {
  Key,
  Copy,
  CheckCircle,
  AlertTriangle,
  RefreshCw,
  Shield,
  Eye,
  EyeOff,
  Clock,
  Terminal,
  Lock,
} from 'lucide-react';

interface GeneratedToken {
  id: string;
  token: string;
  createdAt: Date;
  expiresAt: Date;
  type: 'user' | 'bot';
}

export function TokenGenerator() {
  const { user, setToken: setUserToken } = useAuthStore();
  const [email, setEmail] = useState(user?.email || '');
  const [password, setPassword] = useState('');
  const [twoFactorCode, setTwoFactorCode] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedToken, setGeneratedToken] = useState<GeneratedToken | null>(null);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [showToken, setShowToken] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleGenerateToken = async () => {
    setError('');
    setSuccess('');
    setIsGenerating(true);

    // Simulate token generation process
    setTimeout(() => {
      setIsGenerating(false);

      if (!email || !password) {
        setError('Please provide both email and password');
        return;
      }

      // Generate a mock token
      const mockToken = `${btoa(user?.id || '').replace(/=/g, '')}.${Math.random().toString(36).substring(2, 15)}.${Math.random().toString(36).substring(2, 15)}`;
      
      const newToken: GeneratedToken = {
        id: Math.random().toString(36).substr(2, 9),
        token: mockToken,
        createdAt: new Date(),
        expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days
        type: 'user',
      };

      setGeneratedToken(newToken);
      setUserToken(mockToken);
      setSuccess('Token generated successfully! Store it securely.');
    }, 2000);
  };

  const handleCopyToken = () => {
    if (generatedToken) {
      navigator.clipboard.writeText(generatedToken.token);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-white flex items-center gap-3">
            <Key className="w-8 h-8 text-cyan-400" />
            Token Generator
          </h1>
          <p className="text-slate-400 mt-1">
            Generate Discord user tokens for your account
          </p>
        </div>
        <Badge className="bg-cyan-500/20 text-cyan-400 border-cyan-500/30">
          <Shield className="w-4 h-4 mr-1" />
          Secure
        </Badge>
      </div>

      {/* Info Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="glass-card">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-green-500/20 flex items-center justify-center">
              <Lock className="w-5 h-5 text-green-400" />
            </div>
            <div>
              <p className="text-white font-medium">Secure Generation</p>
              <p className="text-slate-500 text-sm">Encrypted token creation</p>
            </div>
          </CardContent>
        </Card>
        <Card className="glass-card">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-amber-500/20 flex items-center justify-center">
              <Clock className="w-5 h-5 text-amber-400" />
            </div>
            <div>
              <p className="text-white font-medium">7-Day Expiry</p>
              <p className="text-slate-500 text-sm">Tokens expire after 7 days</p>
            </div>
          </CardContent>
        </Card>
        <Card className="glass-card">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-purple-500/20 flex items-center justify-center">
              <Terminal className="w-5 h-5 text-purple-400" />
            </div>
            <div>
              <p className="text-white font-medium">Full Access</p>
              <p className="text-slate-500 text-sm">Use with all features</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Token Generation Form */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="text-white">Generate Token</CardTitle>
          <CardDescription className="text-slate-400">
            Enter your Discord credentials to generate a new token
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {error && (
            <Alert variant="destructive" className="bg-red-500/10 border-red-500/20">
              <AlertDescription className="text-red-400">{error}</AlertDescription>
            </Alert>
          )}
          {success && (
            <Alert className="bg-green-500/10 border-green-500/20">
              <CheckCircle className="w-5 h-5 text-green-400" />
              <AlertDescription className="text-green-400">{success}</AlertDescription>
            </Alert>
          )}

          <div className="space-y-2">
            <Label htmlFor="email" className="text-slate-300">Email</Label>
            <Input
              id="email"
              type="email"
              placeholder="you@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="bg-slate-800/50 border-slate-700 text-white placeholder:text-slate-500"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="password" className="text-slate-300">Password</Label>
            <div className="relative">
              <Input
                id="password"
                type={showPassword ? 'text' : 'password'}
                placeholder="Your Discord password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="bg-slate-800/50 border-slate-700 text-white placeholder:text-slate-500 pr-10"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="2fa" className="text-slate-300">2FA Code (if enabled)</Label>
            <Input
              id="2fa"
              type="text"
              placeholder="000000"
              value={twoFactorCode}
              onChange={(e) => setTwoFactorCode(e.target.value)}
              maxLength={6}
              className="bg-slate-800/50 border-slate-700 text-white placeholder:text-slate-500"
            />
          </div>

          <Button
            onClick={handleGenerateToken}
            disabled={isGenerating || !email || !password}
            className="w-full bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-400 hover:to-purple-500"
          >
            {isGenerating ? (
              <><RefreshCw className="mr-2 h-4 w-4 animate-spin" /> Generating...</>
            ) : (
              <><Key className="mr-2 h-4 w-4" /> Generate Token</>
            )}
          </Button>
        </CardContent>
      </Card>

      {/* Generated Token Display */}
      {generatedToken && (
        <Card className="glass-card border-green-500/30">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <CheckCircle className="w-5 h-5 text-green-400" />
              Token Generated
            </CardTitle>
            <CardDescription className="text-slate-400">
              Your token has been generated successfully. Copy and store it securely.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label className="text-slate-300">Your Token</Label>
              <div className="relative">
                <Input
                  type={showToken ? 'text' : 'password'}
                  value={generatedToken.token}
                  readOnly
                  className="bg-slate-800/50 border-slate-700 text-white font-mono text-sm pr-24"
                />
                <div className="absolute right-2 top-1/2 -translate-y-1/2 flex gap-1">
                  <button
                    onClick={() => setShowToken(!showToken)}
                    className="p-1.5 rounded hover:bg-slate-700 text-slate-400 hover:text-white"
                  >
                    {showToken ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                  <button
                    onClick={handleCopyToken}
                    className="p-1.5 rounded hover:bg-slate-700 text-slate-400 hover:text-white"
                  >
                    {copied ? <CheckCircle className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="p-3 rounded-lg bg-slate-800/50">
                <p className="text-slate-500 text-sm">Created At</p>
                <p className="text-white">{generatedToken.createdAt.toLocaleString()}</p>
              </div>
              <div className="p-3 rounded-lg bg-slate-800/50">
                <p className="text-slate-500 text-sm">Expires At</p>
                <p className="text-white">{generatedToken.expiresAt.toLocaleString()}</p>
              </div>
            </div>

            <Alert className="bg-amber-500/10 border-amber-500/20">
              <AlertTriangle className="w-5 h-5 text-amber-400" />
              <AlertDescription className="text-amber-200">
                <strong>Important:</strong> Never share your token with anyone. Treat it like a password. 
                If compromised, regenerate it immediately from Discord settings.
              </AlertDescription>
            </Alert>
          </CardContent>
        </Card>
      )}

      {/* Instructions */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="text-white">How to Use</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <p className="text-slate-300 font-medium">1. Generate Your Token</p>
            <p className="text-slate-500 text-sm">
              Enter your Discord credentials above and click "Generate Token". 
              If you have 2FA enabled, enter your 2FA code.
            </p>
          </div>
          <div className="space-y-2">
            <p className="text-slate-300 font-medium">2. Copy and Store Securely</p>
            <p className="text-slate-500 text-sm">
              Copy your generated token and store it in a secure location. 
              The token will expire after 7 days for security reasons.
            </p>
          </div>
          <div className="space-y-2">
            <p className="text-slate-300 font-medium">3. Use with Features</p>
            <p className="text-slate-500 text-sm">
              Use this token with any of the dashboard features like Quest Automation, 
              Server Cloner, Snipers, and more.
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Security Notice */}
      <Alert className="bg-red-500/10 border-red-500/20">
        <AlertTriangle className="w-5 h-5 text-red-400" />
        <AlertDescription className="text-red-200">
          <strong>Security Warning:</strong> Using user tokens violates Discord's Terms of Service 
          and may result in account termination. Use at your own risk. We recommend using alt accounts.
        </AlertDescription>
      </Alert>
    </div>
  );
}
