import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useAuthStore } from '@/store/authStore';
import {
  Shield,
  Crown,
  Loader2,
  CheckCircle,
  Clock,
  Globe,
  Monitor,
  RefreshCw,
  Key,
  AlertTriangle,
} from 'lucide-react';

interface SecurityLog {
  id: string;
  action: string;
  timestamp: Date;
  details: string;
  ip?: string;
  location?: string;
}

interface Session {
  id: string;
  device: string;
  location: string;
  os: string;
  lastActive: Date;
  isCurrent: boolean;
}

export function TokenSecurity() {
  const { user } = useAuthStore();
  const isPremium = user?.isPremium;
  
  const [token, setToken] = useState('');
  const [showTokenInput, setShowTokenInput] = useState(true);
  const [isScanning, setIsScanning] = useState(false);
  const [scanComplete, setScanComplete] = useState(false);
  const [suspiciousSessions, setSuspiciousSessions] = useState(0);

  const [logs] = useState<SecurityLog[]>([
    { id: '1', action: 'Token generated', timestamp: new Date(Date.now() - 86400000), details: 'New token created', ip: '192.168.1.1', location: 'New York, US' },
    { id: '2', action: 'Security check', timestamp: new Date(Date.now() - 172800000), details: 'No issues found', ip: '192.168.1.1', location: 'New York, US' },
    { id: '3', action: 'Login detected', timestamp: new Date(Date.now() - 259200000), details: 'Successful login', ip: '192.168.1.1', location: 'New York, US' },
  ]);

  const [sessions] = useState<Session[]>([
    { id: '1', device: 'Chrome on Windows', location: 'New York, US', os: 'Windows 10', lastActive: new Date(), isCurrent: true },
    { id: '2', device: 'Discord Mobile', location: 'New York, US', os: 'iOS', lastActive: new Date(Date.now() - 3600000), isCurrent: false },
  ]);

  const handleScan = async () => {
    setIsScanning(true);
    setScanComplete(false);

    setTimeout(() => {
      setIsScanning(false);
      setScanComplete(true);
      setSuspiciousSessions(0);
    }, 2000);
  };

  if (showTokenInput) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-white flex items-center gap-3">
            <Shield className="w-8 h-8 text-cyan-400" />
            Token Security
          </h1>
          <p className="text-slate-400 mt-1">
            Monitor and protect your Discord tokens
          </p>
        </div>

        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="text-white">Authentication Required</CardTitle>
            <CardDescription className="text-slate-400">
              Please provide your Discord user token to check security
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="token" className="text-slate-300">Discord User Token</Label>
              <Input
                id="token"
                type="password"
                placeholder="Enter your Discord token..."
                value={token}
                onChange={(e) => setToken(e.target.value)}
                className="bg-slate-800/50 border-slate-700 text-white placeholder:text-slate-500"
              />
            </div>
            <Button
              onClick={() => setShowTokenInput(false)}
              disabled={!token}
              className="bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-400 hover:to-purple-500"
            >
              Continue
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-white flex items-center gap-3">
            <Shield className="w-8 h-8 text-cyan-400" />
            Token Security
          </h1>
          <p className="text-slate-400 mt-1">
            Monitor and protect your Discord tokens
          </p>
        </div>
        <Badge className={isPremium 
          ? 'bg-gradient-to-r from-yellow-500 to-amber-500 text-white' 
          : 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30'
        }>
          {isPremium ? <><Crown className="w-4 h-4 mr-1" /> Premium</> : 'Free'}
        </Badge>
      </div>

      {/* Security Scanner */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Shield className="w-5 h-5" />
            Security Scanner
          </CardTitle>
          <CardDescription className="text-slate-400">
            Scan for potential token leaks and suspicious activity
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {!scanComplete ? (
            <Button
              onClick={handleScan}
              disabled={isScanning}
              className="bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-400 hover:to-purple-500"
            >
              {isScanning ? (
                <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Scanning...</>
              ) : (
                <><Shield className="mr-2 h-4 w-4" /> Start Security Scan</>
              )}
            </Button>
          ) : (
            <div className="space-y-4">
              <div className="flex items-center gap-3 p-4 rounded-lg bg-green-500/10 border border-green-500/20">
                <CheckCircle className="w-8 h-8 text-green-400" />
                <div>
                  <p className="text-white font-medium">Scan Complete</p>
                  <p className="text-slate-400 text-sm">
                    {suspiciousSessions === 0 
                      ? 'No suspicious activity detected' 
                      : `Found ${suspiciousSessions} suspicious session(s)`}
                  </p>
                </div>
              </div>
              <Button
                onClick={() => setScanComplete(false)}
                variant="outline"
                className="border-slate-700"
              >
                <RefreshCw className="mr-2 h-4 w-4" />
                Scan Again
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Tabs */}
      <Tabs defaultValue="sessions" className="w-full">
        <TabsList className="bg-slate-800/50">
          <TabsTrigger value="sessions" className="data-[state=active]:bg-cyan-500/20 data-[state=active]:text-cyan-400">
            <Monitor className="w-4 h-4 mr-2" />
            Active Sessions
          </TabsTrigger>
          <TabsTrigger value="logs" className="data-[state=active]:bg-cyan-500/20 data-[state=active]:text-cyan-400">
            <Clock className="w-4 h-4 mr-2" />
            Usage History
          </TabsTrigger>
          <TabsTrigger value="regenerate" className="data-[state=active]:bg-cyan-500/20 data-[state=active]:text-cyan-400">
            <Key className="w-4 h-4 mr-2" />
            Regenerate
          </TabsTrigger>
        </TabsList>

        <TabsContent value="sessions" className="mt-4">
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="text-white">Active Sessions</CardTitle>
              <CardDescription className="text-slate-400">
                Devices currently logged into your account
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {sessions.map((session) => (
                  <div
                    key={session.id}
                    className={`flex items-center justify-between p-4 rounded-lg ${
                      session.isCurrent ? 'bg-cyan-500/10 border border-cyan-500/30' : 'bg-slate-800/50'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <Monitor className="w-5 h-5 text-slate-400" />
                      <div>
                        <p className="text-white font-medium flex items-center gap-2">
                          {session.device}
                          {session.isCurrent && (
                            <Badge className="bg-cyan-500/20 text-cyan-400">Current</Badge>
                          )}
                        </p>
                        <p className="text-slate-500 text-sm">
                          {session.os} • {session.location}
                        </p>
                        <p className="text-slate-600 text-xs">
                          Last active: {session.lastActive.toLocaleTimeString()}
                        </p>
                      </div>
                    </div>
                    {!session.isCurrent && (
                      <Button variant="destructive" size="sm">
                        Revoke
                      </Button>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="logs" className="mt-4">
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="text-white">Token Usage History</CardTitle>
              <CardDescription className="text-slate-400">
                Recent token activity and events
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {logs.map((log) => (
                  <div
                    key={log.id}
                    className="flex items-start gap-3 p-4 rounded-lg bg-slate-800/50"
                  >
                    <Clock className="w-5 h-5 text-slate-400 mt-0.5" />
                    <div className="flex-1">
                      <p className="text-white font-medium">{log.action}</p>
                      <p className="text-slate-500 text-sm">{log.details}</p>
                      <div className="flex items-center gap-4 mt-1 text-xs text-slate-600">
                        <span className="flex items-center gap-1">
                          <Globe className="w-3 h-3" />
                          {log.ip}
                        </span>
                        <span>{log.location}</span>
                        <span>{log.timestamp.toLocaleString()}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="regenerate" className="mt-4">
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Key className="w-5 h-5" />
                Regenerate Token
              </CardTitle>
              <CardDescription className="text-slate-400">
                Generate a new token and invalidate the current one
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {!isPremium && (
                <div className="p-4 rounded-lg bg-yellow-500/10 border border-yellow-500/20">
                  <p className="text-yellow-200 flex items-center gap-2">
                    <Crown className="w-4 h-4" />
                    Token regeneration is a Premium feature
                  </p>
                </div>
              )}
              <div className="p-4 rounded-lg bg-red-500/10 border border-red-500/20">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="w-5 h-5 text-red-400 flex-shrink-0" />
                  <div>
                    <p className="text-red-200 font-medium">Warning</p>
                    <p className="text-red-200/80 text-sm">
                      Regenerating your token will log you out of all devices and 
                      require you to update the token in all applications.
                    </p>
                  </div>
                </div>
              </div>
              <Button
                disabled={!isPremium}
                variant="destructive"
              >
                <RefreshCw className="mr-2 h-4 w-4" />
                Regenerate Token
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
