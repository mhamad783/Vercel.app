import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useAuthStore } from '@/store/authStore';
import { useFeatureStore } from '@/store/featureStore';
import {
  Gift,
  Crown,
  Trophy,
  Sparkles,
  X,
  Settings,
  MessageSquare,
  Clock,
  CheckCircle,
  AlertTriangle,
} from 'lucide-react';

interface BlacklistItem {
  id: string;
  keyword: string;
}

interface SniperLog {
  id: string;
  type: 'giveaway' | 'nitro';
  message: string;
  timestamp: Date;
  status: 'success' | 'failed' | 'pending';
}

export function Snipers() {
  const { user } = useAuthStore();
  const { giveawaySniper, nitroSniper, setGiveawaySniper, setNitroSniper } = useFeatureStore();
  
  const [token, setToken] = useState('');
  const [showTokenInput, setShowTokenInput] = useState(true);
  const [isVerifying, setIsVerifying] = useState(false);
  const [error, setError] = useState('');
  const [newBlacklistItem, setNewBlacklistItem] = useState('');
  const [blacklist, setBlacklist] = useState<BlacklistItem[]>([
    { id: '1', keyword: 'fake' },
    { id: '2', keyword: 'scam' },
  ]);
  const [logs, setLogs] = useState<SniperLog[]>([
    { id: '1', type: 'giveaway', message: 'Entered giveaway in Server Name', timestamp: new Date(Date.now() - 3600000), status: 'success' },
    { id: '2', type: 'nitro', message: 'Detected nitro code (already claimed)', timestamp: new Date(Date.now() - 7200000), status: 'failed' },
  ]);

  const isPremium = user?.isPremium;

  const handleVerifyToken = async () => {
    setError('');
    setIsVerifying(true);

    setTimeout(() => {
      setIsVerifying(false);
      if (token.length < 20) {
        setError('Invalid token format. Please provide a valid Discord user token.');
        return;
      }
      setShowTokenInput(false);
    }, 1500);
  };

  const handleToggleGiveawaySniper = () => {
    setGiveawaySniper(!giveawaySniper);
    if (!giveawaySniper) {
      setLogs(prev => [{
        id: Math.random().toString(36).substr(2, 9),
        type: 'giveaway',
        message: 'Giveaway sniper activated',
        timestamp: new Date(),
        status: 'success'
      }, ...prev]);
    }
  };

  const handleToggleNitroSniper = () => {
    if (!isPremium) {
      setError('Nitro Sniper is a Premium feature only');
      return;
    }
    setNitroSniper(!nitroSniper);
    if (!nitroSniper) {
      setLogs(prev => [{
        id: Math.random().toString(36).substr(2, 9),
        type: 'nitro',
        message: 'Nitro sniper activated',
        timestamp: new Date(),
        status: 'success'
      }, ...prev]);
    }
  };

  const handleAddBlacklist = () => {
    if (!newBlacklistItem.trim()) return;
    setBlacklist(prev => [...prev, { id: Math.random().toString(36).substr(2, 9), keyword: newBlacklistItem }]);
    setNewBlacklistItem('');
  };

  const handleRemoveBlacklist = (id: string) => {
    setBlacklist(prev => prev.filter(item => item.id !== id));
  };

  if (showTokenInput) {
    return (
      <div className="space-y-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-white flex items-center gap-3">
              <Gift className="w-8 h-8 text-cyan-400" />
              Snipers
            </h1>
            <p className="text-slate-400 mt-1">
              Auto-enter giveaways and claim Nitro codes
            </p>
          </div>
        </div>

        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="text-white">Authentication Required</CardTitle>
            <CardDescription className="text-slate-400">
              Please provide your Discord user token to use the snipers
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {error && (
              <Alert variant="destructive" className="bg-red-500/10 border-red-500/20">
                <AlertDescription className="text-red-400">{error}</AlertDescription>
              </Alert>
            )}
            <div className="space-y-2">
              <Label htmlFor="token" className="text-slate-300">Discord User Token</Label>
              <Input
                id="token"
                type="password"
                placeholder="Enter your Discord token..."
                value={token}
                onChange={(e) => setToken(e.target.value)}
                className="bg-slate-800/50 border-slate-700 text-white placeholder:text-slate-500"
              />
            </div>
            <Button
              onClick={handleVerifyToken}
              disabled={isVerifying || !token}
              className="bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-400 hover:to-purple-500"
            >
              {isVerifying ? (
                <><span className="animate-spin mr-2">⏳</span> Verifying...</>
              ) : (
                'Verify Token'
              )}
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-white flex items-center gap-3">
            <Gift className="w-8 h-8 text-cyan-400" />
            Snipers
          </h1>
          <p className="text-slate-400 mt-1">
            Auto-enter giveaways and claim Nitro codes
          </p>
        </div>
        <Badge className={isPremium 
          ? 'bg-gradient-to-r from-yellow-500 to-amber-500 text-white' 
          : 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30'
        }>
          {isPremium ? <><Crown className="w-4 h-4 mr-1" /> Premium</> : 'Free Mode'}
        </Badge>
      </div>

      {/* Sniper Controls */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Giveaway Sniper */}
        <Card className={`glass-card transition-all duration-300 ${giveawaySniper ? 'border-green-500/30 glow-cyan' : ''}`}>
          <CardContent className="p-6">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-4">
                <div className={`w-14 h-14 rounded-xl flex items-center justify-center ${
                  giveawaySniper ? 'bg-green-500/20' : 'bg-slate-700/50'
                }`}>
                  <Trophy className={`w-7 h-7 ${giveawaySniper ? 'text-green-400' : 'text-slate-400'}`} />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-white">Giveaway Sniper</h3>
                  <p className="text-slate-400 text-sm">Auto-enter giveaways</p>
                  <div className="flex items-center gap-2 mt-1">
                    <Badge variant={giveawaySniper ? 'default' : 'outline'}
                      className={giveawaySniper ? 'bg-green-500/20 text-green-400 border-green-500/30' : 'border-slate-600 text-slate-400'}
                    >
                      {giveawaySniper ? 'Active' : 'Inactive'}
                    </Badge>
                  </div>
                </div>
              </div>
              <Switch
                checked={giveawaySniper}
                onCheckedChange={handleToggleGiveawaySniper}
              />
            </div>

            {giveawaySniper && (
              <div className="mt-4 pt-4 border-t border-slate-700 space-y-2">
                <div className="flex items-center gap-2 text-sm text-slate-400">
                  <CheckCircle className="w-4 h-4 text-green-400" />
                  Button click support
                </div>
                <div className="flex items-center gap-2 text-sm text-slate-400">
                  <CheckCircle className="w-4 h-4 text-green-400" />
                  Reaction support
                </div>
                <div className="flex items-center gap-2 text-sm text-slate-400">
                  <CheckCircle className="w-4 h-4 text-green-400" />
                  Random delays (2-7s)
                </div>
                <div className="flex items-center gap-2 text-sm text-slate-400">
                  <CheckCircle className="w-4 h-4 text-green-400" />
                  Keyword filtering
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Nitro Sniper */}
        <Card className={`glass-card transition-all duration-300 ${nitroSniper ? 'border-purple-500/30 glow-purple' : ''}`}>
          <CardContent className="p-6">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-4">
                <div className={`w-14 h-14 rounded-xl flex items-center justify-center ${
                  nitroSniper ? 'bg-purple-500/20' : 'bg-slate-700/50'
                }`}>
                  <Sparkles className={`w-7 h-7 ${nitroSniper ? 'text-purple-400' : 'text-slate-400'}`} />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-lg font-semibold text-white">Nitro Sniper</h3>
                    <Crown className="w-4 h-4 text-yellow-400" />
                  </div>
                  <p className="text-slate-400 text-sm">Auto-claim Nitro codes</p>
                  <div className="flex items-center gap-2 mt-1">
                    <Badge variant={nitroSniper ? 'default' : 'outline'}
                      className={nitroSniper ? 'bg-purple-500/20 text-purple-400 border-purple-500/30' : 'border-slate-600 text-slate-400'}
                    >
                      {nitroSniper ? 'Active' : 'Inactive'}
                    </Badge>
                    {!isPremium && (
                      <Badge variant="outline" className="border-yellow-500/30 text-yellow-400">
                        Premium
                      </Badge>
                    )}
                  </div>
                </div>
              </div>
              <Switch
                checked={nitroSniper}
                onCheckedChange={handleToggleNitroSniper}
                disabled={!isPremium}
              />
            </div>

            {nitroSniper && (
              <div className="mt-4 pt-4 border-t border-slate-700 space-y-2">
                <div className="flex items-center gap-2 text-sm text-slate-400">
                  <CheckCircle className="w-4 h-4 text-purple-400" />
                  Instant claim
                </div>
                <div className="flex items-center gap-2 text-sm text-slate-400">
                  <CheckCircle className="w-4 h-4 text-purple-400" />
                  All code formats supported
                </div>
                <div className="flex items-center gap-2 text-sm text-slate-400">
                  <CheckCircle className="w-4 h-4 text-purple-400" />
                  Real-time monitoring
                </div>
              </div>
            )}

            {!isPremium && (
              <div className="mt-4 p-3 rounded-lg bg-yellow-500/10 border border-yellow-500/20">
                <p className="text-sm text-yellow-200">
                  <Crown className="w-4 h-4 inline mr-1" />
                  Upgrade to Premium to unlock Nitro Sniper
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Tabs for Settings and Logs */}
      <Tabs defaultValue="settings" className="w-full">
        <TabsList className="bg-slate-800/50">
          <TabsTrigger value="settings" className="data-[state=active]:bg-cyan-500/20 data-[state=active]:text-cyan-400">
            <Settings className="w-4 h-4 mr-2" />
            Settings
          </TabsTrigger>
          <TabsTrigger value="logs" className="data-[state=active]:bg-cyan-500/20 data-[state=active]:text-cyan-400">
            <MessageSquare className="w-4 h-4 mr-2" />
            Activity Log
          </TabsTrigger>
        </TabsList>

        <TabsContent value="settings" className="mt-4 space-y-4">
          {/* Blacklist Settings */}
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="text-white">Giveaway Blacklist</CardTitle>
              <CardDescription className="text-slate-400">
                Skip giveaways containing these keywords
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex gap-2">
                <Input
                  placeholder="Add keyword..."
                  value={newBlacklistItem}
                  onChange={(e) => setNewBlacklistItem(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleAddBlacklist()}
                  className="bg-slate-800/50 border-slate-700 text-white placeholder:text-slate-500"
                />
                <Button onClick={handleAddBlacklist} variant="secondary">
                  Add
                </Button>
              </div>

              <div className="flex flex-wrap gap-2">
                {blacklist.map((item) => (
                  <Badge
                    key={item.id}
                    variant="secondary"
                    className="bg-slate-700/50 text-slate-300 hover:bg-slate-700 cursor-pointer group"
                  >
                    {item.keyword}
                    <X
                      className="w-3 h-3 ml-1 opacity-0 group-hover:opacity-100 transition-opacity"
                      onClick={() => handleRemoveBlacklist(item.id)}
                    />
                  </Badge>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="logs" className="mt-4">
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="text-white">Activity Log</CardTitle>
              <CardDescription className="text-slate-400">
                Recent sniper activity
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {logs.map((log) => (
                  <div
                    key={log.id}
                    className="flex items-center gap-3 p-3 rounded-lg bg-slate-800/50"
                  >
                    {log.type === 'giveaway' ? (
                      <Trophy className="w-5 h-5 text-green-400" />
                    ) : (
                      <Sparkles className="w-5 h-5 text-purple-400" />
                    )}
                    <div className="flex-1">
                      <p className="text-white text-sm">{log.message}</p>
                      <p className="text-slate-500 text-xs">
                        <Clock className="w-3 h-3 inline mr-1" />
                        {log.timestamp.toLocaleTimeString()}
                      </p>
                    </div>
                    <Badge
                      variant={log.status === 'success' ? 'default' : 'destructive'}
                      className={log.status === 'success' ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}
                    >
                      {log.status}
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Disclaimer */}
      <Alert className="bg-amber-500/10 border-amber-500/20">
        <AlertTriangle className="w-5 h-5 text-amber-400" />
        <AlertDescription className="text-amber-200">
          <strong>Disclaimer:</strong> Snipers use selfbot technology which violates Discord's Terms of Service. 
          Use at your own risk. We are NOT responsible for any account bans.
        </AlertDescription>
      </Alert>
    </div>
  );
}
