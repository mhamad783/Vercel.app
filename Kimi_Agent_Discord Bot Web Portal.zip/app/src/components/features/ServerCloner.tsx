import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useAuthStore } from '@/store/authStore';
import { useFeatureStore } from '@/store/featureStore';
import {
  Copy,
  Play,
  Square,
  Loader2,
  CheckCircle,
  AlertTriangle,
  Crown,
  Server,
  Smile,
  Sticker,
  Users,
  MessageSquare,
  Settings,
} from 'lucide-react';

interface CloneStep {
  id: string;
  name: string;
  description: string;
  status: 'pending' | 'running' | 'completed' | 'error';
  progress: number;
}

export function ServerCloner() {
  const { user } = useAuthStore();
  const { cloneRunning, cloneProgress, setCloneRunning, setCloneProgress, addOperation, updateOperation } = useFeatureStore();
  
  const [token, setToken] = useState('');
  const [showTokenInput, setShowTokenInput] = useState(true);
  const [isVerifying, setIsVerifying] = useState(false);
  const [error, setError] = useState('');
  const [sourceGuildId, setSourceGuildId] = useState('');
  const [targetGuildId, setTargetGuildId] = useState('');
  const [cloneType, setCloneType] = useState<'full' | 'emojis' | 'stickers'>('full');
  
  const [steps, setSteps] = useState<CloneStep[]>([
    { id: '1', name: 'Delete Existing Content', description: 'Removing channels and roles from target server', status: 'pending', progress: 0 },
    { id: '2', name: 'Clone Roles', description: 'Creating roles from source server', status: 'pending', progress: 0 },
    { id: '3', name: 'Clone Channels', description: 'Creating channels and categories', status: 'pending', progress: 0 },
    { id: '4', name: 'Clone Server Info', description: 'Updating name, icon, and settings', status: 'pending', progress: 0 },
  ]);

  const isPremium = user?.isPremium;
  const cloneUsage = 0; // This would come from store
  const maxFreeClones = 3;
  const remainingClones = maxFreeClones - cloneUsage;
  const canClone = isPremium || remainingClones > 0;

  const handleVerifyToken = async () => {
    setError('');
    setIsVerifying(true);

    setTimeout(() => {
      setIsVerifying(false);
      if (token.length < 20) {
        setError('Invalid token format. Please provide a valid Discord user token.');
        return;
      }
      setShowTokenInput(false);
    }, 1500);
  };

  const handleStartClone = async () => {
    if (!sourceGuildId || !targetGuildId) {
      setError('Please provide both source and target server IDs');
      return;
    }

    setCloneRunning(true);
    setError('');

    const operationId = Math.random().toString(36).substr(2, 9);
    addOperation({
      id: operationId,
      type: `Server Clone (${cloneType})`,
      status: 'running',
      progress: 0,
      message: `Starting ${cloneType} clone...`,
      startedAt: new Date(),
    });

    // Simulate clone process
    let totalProgress = 0;
    const interval = setInterval(() => {
      totalProgress += 1;
      setCloneProgress(Math.min(totalProgress, 100));
      
      updateOperation(operationId, {
        progress: Math.min(totalProgress, 100),
        message: `Cloning server... ${Math.min(totalProgress, 100)}%`,
      });

      // Update step progress
      setSteps(prev => prev.map((step, i) => {
        const stepStart = i * 25;
        const stepEnd = (i + 1) * 25;
        
        if (totalProgress >= stepStart && totalProgress < stepEnd) {
          return { 
            ...step, 
            status: 'running', 
            progress: Math.min(((totalProgress - stepStart) / 25) * 100, 100) 
          };
        }
        if (totalProgress >= stepEnd) {
          return { ...step, status: 'completed', progress: 100 };
        }
        return step;
      }));

      if (totalProgress >= 100) {
        clearInterval(interval);
        setCloneRunning(false);
        updateOperation(operationId, {
          status: 'completed',
          progress: 100,
          message: 'Server cloned successfully!',
        });
      }
    }, 200);
  };

  const handleStopClone = () => {
    setCloneRunning(false);
    setCloneProgress(0);
    setSteps(prev => prev.map(s => ({ ...s, status: 'pending', progress: 0 })));
  };

  if (showTokenInput) {
    return (
      <div className="space-y-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-white flex items-center gap-3">
              <Copy className="w-8 h-8 text-cyan-400" />
              Server Cloner
            </h1>
            <p className="text-slate-400 mt-1">
              Clone entire servers, emojis, or stickers
            </p>
          </div>
          {!isPremium && (
            <Badge variant="outline" className="border-cyan-500/30 text-cyan-400">
              {remainingClones} free clones remaining
            </Badge>
          )}
        </div>

        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="text-white">Authentication Required</CardTitle>
            <CardDescription className="text-slate-400">
              Please provide your Discord user token to use the server cloner
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {error && (
              <Alert variant="destructive" className="bg-red-500/10 border-red-500/20">
                <AlertDescription className="text-red-400">{error}</AlertDescription>
              </Alert>
            )}
            <div className="space-y-2">
              <Label htmlFor="token" className="text-slate-300">Discord User Token</Label>
              <Input
                id="token"
                type="password"
                placeholder="Enter your Discord token..."
                value={token}
                onChange={(e) => setToken(e.target.value)}
                className="bg-slate-800/50 border-slate-700 text-white placeholder:text-slate-500"
              />
            </div>
            <Button
              onClick={handleVerifyToken}
              disabled={isVerifying || !token}
              className="bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-400 hover:to-purple-500"
            >
              {isVerifying ? (
                <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Verifying...</>
              ) : (
                'Verify Token'
              )}
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!canClone) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-white flex items-center gap-3">
            <Copy className="w-8 h-8 text-cyan-400" />
            Server Cloner
          </h1>
        </div>

        <Card className="glass-card border-yellow-500/30">
          <CardContent className="p-8 text-center">
            <Crown className="w-16 h-16 text-yellow-400 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-white mb-2">Clone Limit Reached</h2>
            <p className="text-slate-400 mb-6">
              You've used all <strong>{maxFreeClones}</strong> free clones.
              Upgrade to Premium for unlimited clones!
            </p>
            <div className="space-y-2 text-left max-w-md mx-auto mb-6">
              <p className="text-slate-300 flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-green-400" />
                Unlimited server clones
              </p>
              <p className="text-slate-300 flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-green-400" />
                Priority processing
              </p>
              <p className="text-slate-300 flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-green-400" />
                All premium features
              </p>
            </div>
            <Button className="bg-gradient-to-r from-yellow-500 to-amber-500 hover:from-yellow-400 hover:to-amber-400">
              <Crown className="mr-2 h-4 w-4" />
              Upgrade to Premium
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-white flex items-center gap-3">
            <Copy className="w-8 h-8 text-cyan-400" />
            Server Cloner
          </h1>
          <p className="text-slate-400 mt-1">
            Clone entire servers, emojis, or stickers
          </p>
        </div>
        <Badge className={isPremium 
          ? 'bg-gradient-to-r from-yellow-500 to-amber-500 text-white' 
          : 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30'
        }>
          {isPremium ? <><Crown className="w-4 h-4 mr-1" /> Unlimited</> : `${remainingClones} remaining`}
        </Badge>
      </div>

      {/* Clone Type Tabs */}
      <Tabs value={cloneType} onValueChange={(v) => setCloneType(v as 'full' | 'emojis' | 'stickers')} className="w-full">
        <TabsList className="grid w-full grid-cols-3 bg-slate-800/50">
          <TabsTrigger value="full" className="data-[state=active]:bg-cyan-500/20 data-[state=active]:text-cyan-400">
            <Server className="w-4 h-4 mr-2" />
            Full Clone
          </TabsTrigger>
          <TabsTrigger value="emojis" className="data-[state=active]:bg-cyan-500/20 data-[state=active]:text-cyan-400">
            <Smile className="w-4 h-4 mr-2" />
            Emojis Only
          </TabsTrigger>
          <TabsTrigger value="stickers" className="data-[state=active]:bg-cyan-500/20 data-[state=active]:text-cyan-400">
            <Sticker className="w-4 h-4 mr-2" />
            Stickers Only
          </TabsTrigger>
        </TabsList>

        <TabsContent value="full" className="mt-4">
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="text-white">Full Server Clone</CardTitle>
              <CardDescription className="text-slate-400">
                Clones everything: roles, channels, categories, emojis, stickers, and server info
              </CardDescription>
            </CardHeader>
          </Card>
        </TabsContent>

        <TabsContent value="emojis" className="mt-4">
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="text-white">Emoji Cloner</CardTitle>
              <CardDescription className="text-slate-400">
                Clone only emojis from one server to another
              </CardDescription>
            </CardHeader>
          </Card>
        </TabsContent>

        <TabsContent value="stickers" className="mt-4">
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="text-white">Sticker Cloner</CardTitle>
              <CardDescription className="text-slate-400">
                Clone only stickers from one server to another
              </CardDescription>
            </CardHeader>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Configuration */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="text-white">Configuration</CardTitle>
          <CardDescription className="text-slate-400">
            Enter the source and target server IDs
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {error && (
            <Alert variant="destructive" className="bg-red-500/10 border-red-500/20">
              <AlertDescription className="text-red-400">{error}</AlertDescription>
            </Alert>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="source" className="text-slate-300 flex items-center gap-2">
                <Server className="w-4 h-4" />
                Source Server ID
              </Label>
              <Input
                id="source"
                placeholder="1234567890123456789"
                value={sourceGuildId}
                onChange={(e) => setSourceGuildId(e.target.value)}
                className="bg-slate-800/50 border-slate-700 text-white placeholder:text-slate-500"
              />
              <p className="text-xs text-slate-500">The server you want to copy FROM</p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="target" className="text-slate-300 flex items-center gap-2">
                <Copy className="w-4 h-4" />
                Target Server ID
              </Label>
              <Input
                id="target"
                placeholder="9876543210987654321"
                value={targetGuildId}
                onChange={(e) => setTargetGuildId(e.target.value)}
                className="bg-slate-800/50 border-slate-700 text-white placeholder:text-slate-500"
              />
              <p className="text-xs text-slate-500">The server you want to copy TO (you need Admin permission)</p>
            </div>
          </div>

          {/* Warning */}
          <Alert className="bg-red-500/10 border-red-500/20">
            <AlertTriangle className="w-5 h-5 text-red-400" />
            <AlertDescription className="text-red-200">
              <strong>Warning:</strong> This will DELETE all existing channels and roles in the target server. 
              This action cannot be undone!
            </AlertDescription>
          </Alert>

          {/* Progress */}
          {cloneRunning && cloneType === 'full' && (
            <div className="space-y-4">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-white font-medium">Overall Progress</span>
                  <span className="text-cyan-400">{cloneProgress}%</span>
                </div>
                <Progress value={cloneProgress} className="h-3" />
              </div>

              <div className="space-y-2">
                {steps.map((step) => (
                  <div
                    key={step.id}
                    className={`flex items-center justify-between p-3 rounded-lg ${
                      step.status === 'running'
                        ? 'bg-amber-500/10'
                        : step.status === 'completed'
                        ? 'bg-green-500/10'
                        : 'bg-slate-800/50'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      {step.status === 'running' && <Loader2 className="w-4 h-4 text-amber-400 animate-spin" />}
                      {step.status === 'completed' && <CheckCircle className="w-4 h-4 text-green-400" />}
                      {step.status === 'pending' && <div className="w-4 h-4 rounded-full border-2 border-slate-600" />}
                      <div>
                        <p className={`text-sm font-medium ${step.status === 'completed' ? 'text-green-400' : 'text-white'}`}>
                          {step.name}
                        </p>
                        <p className="text-xs text-slate-500">{step.description}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex gap-3">
            {!cloneRunning ? (
              <Button
                onClick={handleStartClone}
                className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-400 hover:to-emerald-500"
              >
                <Play className="mr-2 h-4 w-4" />
                Start Clone
              </Button>
            ) : (
              <Button
                onClick={handleStopClone}
                variant="destructive"
              >
                <Square className="mr-2 h-4 w-4" />
                Stop Clone
              </Button>
            )}
            <Button
              variant="outline"
              onClick={() => setShowTokenInput(true)}
              className="border-slate-700 text-slate-300 hover:text-white"
            >
              Change Token
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Features */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="glass-card">
          <CardContent className="p-4 flex items-center gap-3">
            <Users className="w-5 h-5 text-cyan-400" />
            <div>
              <p className="text-white font-medium">Roles</p>
              <p className="text-slate-500 text-sm">All roles with permissions</p>
            </div>
          </CardContent>
        </Card>
        <Card className="glass-card">
          <CardContent className="p-4 flex items-center gap-3">
            <MessageSquare className="w-5 h-5 text-purple-400" />
            <div>
              <p className="text-white font-medium">Channels</p>
              <p className="text-slate-500 text-sm">Categories and channels</p>
            </div>
          </CardContent>
        </Card>
        <Card className="glass-card">
          <CardContent className="p-4 flex items-center gap-3">
            <Settings className="w-5 h-5 text-green-400" />
            <div>
              <p className="text-white font-medium">Server Info</p>
              <p className="text-slate-500 text-sm">Name, icon, settings</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Disclaimer */}
      <Alert className="bg-amber-500/10 border-amber-500/20">
        <AlertTriangle className="w-5 h-5 text-amber-400" />
        <AlertDescription className="text-amber-200">
          <strong>Disclaimer:</strong> Server cloning violates Discord's Terms of Service. 
          Your account may be banned. Use at your own risk.
        </AlertDescription>
      </Alert>
    </div>
  );
}
