import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useAuthStore } from '@/store/authStore';
import {
  Phone,
  Play,
  Square,
  Loader2,
  Crown,
  User,
  Users,
  Volume2,
  AlertTriangle,
} from 'lucide-react';

export function AutoCall() {
  const { user } = useAuthStore();
  const isPremium = user?.isPremium;
  
  const [token, setToken] = useState('');
  const [showTokenInput, setShowTokenInput] = useState(true);
  const [isVerifying, setIsVerifying] = useState(false);
  const [error, setError] = useState('');
  const [activeCall, setActiveCall] = useState(false);
  const [callDuration, setCallDuration] = useState(0);

  const handleVerifyToken = async () => {
    setError('');
    setIsVerifying(true);

    setTimeout(() => {
      setIsVerifying(false);
      if (token.length < 20) {
        setError('Invalid token format');
        return;
      }
      setShowTokenInput(false);
    }, 1500);
  };

  const handleStartCall = () => {
    if (!isPremium) {
      setError('Auto Call is a Premium feature');
      return;
    }
    setActiveCall(true);
    // Simulate call duration counter
    const interval = setInterval(() => {
      setCallDuration(prev => prev + 1);
    }, 1000);
    
    // Stop after 30 seconds for demo
    setTimeout(() => {
      clearInterval(interval);
      setActiveCall(false);
      setCallDuration(0);
    }, 30000);
  };

  const handleStopCall = () => {
    setActiveCall(false);
    setCallDuration(0);
  };

  if (!isPremium) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-white flex items-center gap-3">
            <Phone className="w-8 h-8 text-cyan-400" />
            Auto Call
          </h1>
          <p className="text-slate-400 mt-1">
            Automated voice calls and mass calling
          </p>
        </div>

        <Card className="glass-card border-yellow-500/30">
          <CardContent className="p-8 text-center">
            <Crown className="w-16 h-16 text-yellow-400 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-white mb-2">Premium Feature</h2>
            <p className="text-slate-400 mb-6">
              Auto Call is only available for Premium users.
            </p>
            <div className="space-y-2 text-left max-w-md mx-auto mb-6">
              <p className="text-slate-300 flex items-center gap-2">
                <Phone className="w-4 h-4 text-cyan-400" />
                Call specific users
              </p>
              <p className="text-slate-300 flex items-center gap-2">
                <Users className="w-4 h-4 text-cyan-400" />
                Mass call server members
              </p>
              <p className="text-slate-300 flex items-center gap-2">
                <Volume2 className="w-4 h-4 text-cyan-400" />
                Auto-join voice channels
              </p>
            </div>
            <Button className="bg-gradient-to-r from-yellow-500 to-amber-500 hover:from-yellow-400 hover:to-amber-400">
              <Crown className="mr-2 h-4 w-4" />
              Upgrade to Premium
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (showTokenInput) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-white flex items-center gap-3">
            <Phone className="w-8 h-8 text-cyan-400" />
            Auto Call
          </h1>
          <p className="text-slate-400 mt-1">
            Automated voice calls and mass calling
          </p>
        </div>

        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="text-white">Authentication Required</CardTitle>
            <CardDescription className="text-slate-400">
              Please provide your Discord user token
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {error && (
              <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/20 text-red-400">
                {error}
              </div>
            )}
            <div className="space-y-2">
              <Label htmlFor="token" className="text-slate-300">Discord User Token</Label>
              <Input
                id="token"
                type="password"
                placeholder="Enter your Discord token..."
                value={token}
                onChange={(e) => setToken(e.target.value)}
                className="bg-slate-800/50 border-slate-700 text-white placeholder:text-slate-500"
              />
            </div>
            <Button
              onClick={handleVerifyToken}
              disabled={isVerifying || !token}
              className="bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-400 hover:to-purple-500"
            >
              {isVerifying ? (
                <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Verifying...</>
              ) : (
                'Verify Token'
              )}
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-white flex items-center gap-3">
            <Phone className="w-8 h-8 text-cyan-400" />
            Auto Call
          </h1>
          <p className="text-slate-400 mt-1">
            Automated voice calls and mass calling
          </p>
        </div>
        <Badge className="bg-gradient-to-r from-yellow-500 to-amber-500 text-white">
          <Crown className="w-4 h-4 mr-1" />
          Premium
        </Badge>
      </div>

      {/* Call Types */}
      <Tabs defaultValue="user" className="w-full">
        <TabsList className="bg-slate-800/50">
          <TabsTrigger value="user" className="data-[state=active]:bg-cyan-500/20 data-[state=active]:text-cyan-400">
            <User className="w-4 h-4 mr-2" />
            Call User
          </TabsTrigger>
          <TabsTrigger value="mass" className="data-[state=active]:bg-cyan-500/20 data-[state=active]:text-cyan-400">
            <Users className="w-4 h-4 mr-2" />
            Mass Call
          </TabsTrigger>
          <TabsTrigger value="join" className="data-[state=active]:bg-cyan-500/20 data-[state=active]:text-cyan-400">
            <Volume2 className="w-4 h-4 mr-2" />
            Join VC
          </TabsTrigger>
        </TabsList>

        <TabsContent value="user" className="mt-4">
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="text-white">Call Specific User</CardTitle>
              <CardDescription className="text-slate-400">
                Call a specific Discord user by their ID
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="userId" className="text-slate-300">User ID</Label>
                <Input
                  id="userId"
                  placeholder="1234567890123456789"
                  className="bg-slate-800/50 border-slate-700 text-white placeholder:text-slate-500"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="duration" className="text-slate-300">Duration (seconds)</Label>
                <Input
                  id="duration"
                  type="number"
                  defaultValue={30}
                  className="bg-slate-800/50 border-slate-700 text-white placeholder:text-slate-500"
                />
              </div>
              {!activeCall ? (
                <Button onClick={handleStartCall} className="bg-green-500 hover:bg-green-600">
                  <Play className="mr-2 h-4 w-4" />
                  Start Call
                </Button>
              ) : (
                <div className="space-y-3">
                  <div className="flex items-center gap-2 text-green-400">
                    <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
                    Call in progress - {callDuration}s
                  </div>
                  <Button onClick={handleStopCall} variant="destructive">
                    <Square className="mr-2 h-4 w-4" />
                    End Call
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="mass" className="mt-4">
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="text-white">Mass Call Server</CardTitle>
              <CardDescription className="text-slate-400">
                Call all members in a server (Premium only)
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="guildId" className="text-slate-300">Server ID</Label>
                <Input
                  id="guildId"
                  placeholder="1234567890123456789"
                  className="bg-slate-800/50 border-slate-700 text-white placeholder:text-slate-500"
                />
              </div>
              <Button className="bg-green-500 hover:bg-green-600">
                <Play className="mr-2 h-4 w-4" />
                Start Mass Call
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="join" className="mt-4">
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="text-white">Auto Join Voice Channel</CardTitle>
              <CardDescription className="text-slate-400">
                Automatically join a voice channel
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="vcGuildId" className="text-slate-300">Server ID</Label>
                <Input
                  id="vcGuildId"
                  placeholder="1234567890123456789"
                  className="bg-slate-800/50 border-slate-700 text-white placeholder:text-slate-500"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="channelId" className="text-slate-300">Voice Channel ID</Label>
                <Input
                  id="channelId"
                  placeholder="9876543210987654321"
                  className="bg-slate-800/50 border-slate-700 text-white placeholder:text-slate-500"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="joinDuration" className="text-slate-300">Duration (seconds)</Label>
                <Input
                  id="joinDuration"
                  type="number"
                  defaultValue={60}
                  className="bg-slate-800/50 border-slate-700 text-white placeholder:text-slate-500"
                />
              </div>
              <Button className="bg-green-500 hover:bg-green-600">
                <Volume2 className="mr-2 h-4 w-4" />
                Join Channel
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Disclaimer */}
      <div className="p-4 rounded-lg bg-amber-500/10 border border-amber-500/20">
        <div className="flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-amber-400 flex-shrink-0" />
          <p className="text-amber-200 text-sm">
            <strong>Disclaimer:</strong> Auto calling may violate Discord's Terms of Service. 
            Use at your own risk. We are NOT responsible for any account bans.
          </p>
        </div>
      </div>
    </div>
  );
}
