import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { useAuthStore } from '@/store/authStore';
import {
  User,
  Users,
  Server,
  MessageSquare,
  Shield,
  Crown,
  CreditCard,
  Calendar,
  Globe,
  CheckCircle,
  XCircle,
  Loader2,
  RefreshCw,
  Mail,
  Phone,
} from 'lucide-react';

interface AccountStats {
  username: string;
  displayName: string;
  userId: string;
  email: string;
  phone: string | null;
  mfaEnabled: boolean;
  verified: boolean;
  nitroStatus: string;
  locale: string;
  createdAt: string;
  serverCount: number;
  friendCount: number;
  blockedCount: number;
  dmChannels: number;
  paymentMethods: number;
  hasBanner: boolean;
  hasAvatar: boolean;
  bio: string | null;
}

export function AccountStats() {
  const { user } = useAuthStore();
  const [token, setToken] = useState('');
  const [showTokenInput, setShowTokenInput] = useState(true);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [stats, setStats] = useState<AccountStats | null>(null);

  const handleFetchStats = async () => {
    setError('');
    setIsLoading(true);

    setTimeout(() => {
      setIsLoading(false);
      if (token.length < 20) {
        setError('Invalid token format');
        return;
      }

      // Mock stats data
      setStats({
        username: user?.username || 'unknown',
        displayName: 'Kaizen User',
        userId: user?.id || '123456789',
        email: user?.email || 'user@example.com',
        phone: '+1 *** *** ****',
        mfaEnabled: true,
        verified: true,
        nitroStatus: 'Nitro',
        locale: 'en-US',
        createdAt: '2020-01-15',
        serverCount: 47,
        friendCount: 128,
        blockedCount: 5,
        dmChannels: 89,
        paymentMethods: 2,
        hasBanner: true,
        hasAvatar: true,
        bio: 'Just a Discord user enjoying life!',
      });
      setShowTokenInput(false);
    }, 1500);
  };

  if (showTokenInput) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-white flex items-center gap-3">
            <User className="w-8 h-8 text-cyan-400" />
            Account Statistics
          </h1>
          <p className="text-slate-400 mt-1">
            View detailed statistics about your Discord account
          </p>
        </div>

        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="text-white">Authentication Required</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {error && (
              <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/20 text-red-400">
                {error}
              </div>
            )}
            <div className="space-y-2">
              <Label htmlFor="token" className="text-slate-300">Discord User Token</Label>
              <Input
                id="token"
                type="password"
                placeholder="Enter your Discord token..."
                value={token}
                onChange={(e) => setToken(e.target.value)}
                className="bg-slate-800/50 border-slate-700 text-white placeholder:text-slate-500"
              />
            </div>
            <Button
              onClick={handleFetchStats}
              disabled={isLoading || !token}
              className="bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-400 hover:to-purple-500"
            >
              {isLoading ? (
                <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Fetching...</>
              ) : (
                'Fetch Stats'
              )}
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!stats) return null;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-white flex items-center gap-3">
            <User className="w-8 h-8 text-cyan-400" />
            Account Statistics
          </h1>
          <p className="text-slate-400 mt-1">
            Detailed information about your Discord account
          </p>
        </div>
        <Button
          variant="outline"
          onClick={() => setShowTokenInput(true)}
          className="border-slate-700 text-slate-300 hover:text-white"
        >
          <RefreshCw className="mr-2 h-4 w-4" />
          Refresh
        </Button>
      </div>

      {/* Profile Overview */}
      <Card className="glass-card">
        <CardContent className="p-6">
          <div className="flex items-center gap-6">
            <div className="w-20 h-20 rounded-full bg-gradient-to-br from-cyan-400 to-purple-600 flex items-center justify-center">
              <User className="w-10 h-10 text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-white">{stats.username}</h2>
              <p className="text-slate-400">{stats.displayName}</p>
              <div className="flex items-center gap-2 mt-2">
                <Badge className="bg-purple-500/20 text-purple-400 border-purple-500/30">
                  <Crown className="w-3 h-3 mr-1" />
                  {stats.nitroStatus}
                </Badge>
                {stats.mfaEnabled && (
                  <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
                    <Shield className="w-3 h-3 mr-1" />
                    2FA Enabled
                  </Badge>
                )}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="glass-card">
          <CardContent className="p-4 flex items-center gap-3">
            <Server className="w-8 h-8 text-cyan-400" />
            <div>
              <p className="text-2xl font-bold text-white">{stats.serverCount}</p>
              <p className="text-slate-500 text-sm">Servers</p>
            </div>
          </CardContent>
        </Card>
        <Card className="glass-card">
          <CardContent className="p-4 flex items-center gap-3">
            <Users className="w-8 h-8 text-green-400" />
            <div>
              <p className="text-2xl font-bold text-white">{stats.friendCount}</p>
              <p className="text-slate-500 text-sm">Friends</p>
            </div>
          </CardContent>
        </Card>
        <Card className="glass-card">
          <CardContent className="p-4 flex items-center gap-3">
            <MessageSquare className="w-8 h-8 text-purple-400" />
            <div>
              <p className="text-2xl font-bold text-white">{stats.dmChannels}</p>
              <p className="text-slate-500 text-sm">DM Channels</p>
            </div>
          </CardContent>
        </Card>
        <Card className="glass-card">
          <CardContent className="p-4 flex items-center gap-3">
            <CreditCard className="w-8 h-8 text-amber-400" />
            <div>
              <p className="text-2xl font-bold text-white">{stats.paymentMethods}</p>
              <p className="text-slate-500 text-sm">Payment Methods</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Detailed Info */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="text-white">User Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex justify-between">
              <span className="text-slate-400">User ID</span>
              <span className="text-white font-mono">{stats.userId}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Email</span>
              <span className="text-white flex items-center gap-2">
                <Mail className="w-4 h-4" />
                {stats.email}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Phone</span>
              <span className="text-white flex items-center gap-2">
                <Phone className="w-4 h-4" />
                {stats.phone || 'Not set'}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Locale</span>
              <span className="text-white flex items-center gap-2">
                <Globe className="w-4 h-4" />
                {stats.locale}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Created</span>
              <span className="text-white flex items-center gap-2">
                <Calendar className="w-4 h-4" />
                {stats.createdAt}
              </span>
            </div>
          </CardContent>
        </Card>

        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="text-white">Security & Profile</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-slate-400">MFA Enabled</span>
              {stats.mfaEnabled ? (
                <CheckCircle className="w-5 h-5 text-green-400" />
              ) : (
                <XCircle className="w-5 h-5 text-red-400" />
              )}
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-400">Email Verified</span>
              {stats.verified ? (
                <CheckCircle className="w-5 h-5 text-green-400" />
              ) : (
                <XCircle className="w-5 h-5 text-red-400" />
              )}
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-400">Has Avatar</span>
              {stats.hasAvatar ? (
                <CheckCircle className="w-5 h-5 text-green-400" />
              ) : (
                <XCircle className="w-5 h-5 text-red-400" />
              )}
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-400">Has Banner</span>
              {stats.hasBanner ? (
                <CheckCircle className="w-5 h-5 text-green-400" />
              ) : (
                <XCircle className="w-5 h-5 text-red-400" />
              )}
            </div>
            <div className="pt-2 border-t border-slate-700">
              <span className="text-slate-400">Bio</span>
              <p className="text-white mt-1">{stats.bio || 'No bio set'}</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
