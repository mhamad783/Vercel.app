import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { useFeatureStore } from '@/store/featureStore';
import {
  MessageSquare,
  Square,
  Loader2,
  AlertTriangle,
  Trash2,
  RefreshCw,
} from 'lucide-react';

export function DMPurge() {
  const { addOperation, updateOperation } = useFeatureStore();
  const [token, setToken] = useState('');
  const [showTokenInput, setShowTokenInput] = useState(true);
  const [isVerifying, setIsVerifying] = useState(false);
  const [isRunning, setIsRunning] = useState(false);
  const [error, setError] = useState('');
  const [progress, setProgress] = useState(0);
  const [dmCount, setDmCount] = useState(0);
  const [deletedCount, setDeletedCount] = useState(0);
  const [currentChannel, setCurrentChannel] = useState('');

  const handleVerifyToken = async () => {
    setError('');
    setIsVerifying(true);

    setTimeout(() => {
      setIsVerifying(false);
      if (token.length < 20) {
        setError('Invalid token format');
        return;
      }
      setDmCount(89); // Mock DM count
      setShowTokenInput(false);
    }, 1500);
  };

  const handleStartPurge = async () => {
    setIsRunning(true);
    setError('');
    setProgress(0);
    setDeletedCount(0);

    const operationId = Math.random().toString(36).substr(2, 9);
    addOperation({
      id: operationId,
      type: 'DM Purge',
      status: 'running',
      progress: 0,
      message: 'Starting DM purge...',
      startedAt: new Date(),
    });

    // Simulate purge process
    const channels = ['User1', 'User2', 'User3', 'User4', 'User5'];
    let current = 0;
    
    const interval = setInterval(() => {
      current += 1;
      const percent = Math.min((current / dmCount) * 100, 100);
      setProgress(percent);
      setDeletedCount(current);
      setCurrentChannel(channels[Math.floor(Math.random() * channels.length)] || 'Unknown');

      updateOperation(operationId, {
        progress: percent,
        message: `Purging DMs... ${current}/${dmCount}`,
      });

      if (current >= dmCount) {
        clearInterval(interval);
        setIsRunning(false);
        setCurrentChannel('');
        updateOperation(operationId, {
          status: 'completed',
          progress: 100,
          message: `Deleted ${dmCount} messages`,
        });
      }
    }, 50);
  };

  const handleStop = () => {
    setIsRunning(false);
    setProgress(0);
  };

  if (showTokenInput) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-white flex items-center gap-3">
            <MessageSquare className="w-8 h-8 text-cyan-400" />
            DM Purge
          </h1>
          <p className="text-slate-400 mt-1">
            Delete all messages from your DM channels
          </p>
        </div>

        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="text-white">Authentication Required</CardTitle>
            <CardDescription className="text-slate-400">
              Please provide your Discord user token
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {error && (
              <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/20 text-red-400">
                {error}
              </div>
            )}
            <div className="space-y-2">
              <Label htmlFor="token" className="text-slate-300">Discord User Token</Label>
              <Input
                id="token"
                type="password"
                placeholder="Enter your Discord token..."
                value={token}
                onChange={(e) => setToken(e.target.value)}
                className="bg-slate-800/50 border-slate-700 text-white placeholder:text-slate-500"
              />
            </div>
            <Button
              onClick={handleVerifyToken}
              disabled={isVerifying || !token}
              className="bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-400 hover:to-purple-500"
            >
              {isVerifying ? (
                <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Verifying...</>
              ) : (
                'Verify Token'
              )}
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-white flex items-center gap-3">
          <MessageSquare className="w-8 h-8 text-cyan-400" />
          DM Purge
        </h1>
        <p className="text-slate-400 mt-1">
          Delete all messages from your DM channels
        </p>
      </div>

      {/* Warning Card */}
      <Card className="glass-card border-red-500/30">
        <CardContent className="p-6">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-xl bg-red-500/20 flex items-center justify-center flex-shrink-0">
              <AlertTriangle className="w-6 h-6 text-red-400" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-white">Warning</h3>
              <p className="text-slate-400 mt-1">
                This action will <strong className="text-red-400">DELETE ALL messages you sent in ALL DMs</strong>. 
                This cannot be undone and messages cannot be recovered.
              </p>
              <ul className="mt-3 space-y-1 text-slate-500 text-sm">
                <li>• Messages will be deleted one by one</li>
                <li>• This action <strong>CANNOT be undone</strong></li>
                <li>• Messages <strong>CANNOT be recovered</strong></li>
                <li>• This may take a long time</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Control Panel */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="text-white">Control Panel</CardTitle>
          <CardDescription className="text-slate-400">
            Found <strong className="text-cyan-400">{dmCount}</strong> DM channels
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {isRunning && (
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-white">Progress</span>
                <span className="text-cyan-400">{Math.round(progress)}%</span>
              </div>
              <Progress value={progress} className="h-3" />
              <p className="text-slate-500 text-sm text-center">
                Deleted {deletedCount} messages
              </p>
              {currentChannel && (
                <p className="text-slate-400 text-sm text-center">
                  Processing: {currentChannel}
                </p>
              )}
            </div>
          )}

          <div className="flex gap-3">
            {!isRunning ? (
              <Button
                onClick={handleStartPurge}
                variant="destructive"
                className="bg-red-500 hover:bg-red-600"
              >
                <Trash2 className="mr-2 h-4 w-4" />
                Start DM Purge
              </Button>
            ) : (
              <Button
                onClick={handleStop}
                variant="outline"
                className="border-slate-700"
              >
                <Square className="mr-2 h-4 w-4" />
                Stop
              </Button>
            )}
            <Button
              variant="outline"
              onClick={() => setShowTokenInput(true)}
              className="border-slate-700 text-slate-300 hover:text-white"
            >
              <RefreshCw className="mr-2 h-4 w-4" />
              Change Token
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Disclaimer */}
      <div className="p-4 rounded-lg bg-amber-500/10 border border-amber-500/20">
        <div className="flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-amber-400 flex-shrink-0" />
          <p className="text-amber-200 text-sm">
            <strong>Disclaimer:</strong> This tool uses selfbot technology which violates Discord's Terms of Service. 
            Use at your own risk.
          </p>
        </div>
      </div>
    </div>
  );
}
