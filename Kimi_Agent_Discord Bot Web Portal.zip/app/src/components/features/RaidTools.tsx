import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { useFeatureStore } from '@/store/featureStore';
import {
  Flame,
  Play,
  Square,
  Loader2,
  AlertTriangle,
  MessageSquare,
  Volume2,
} from 'lucide-react';

export function RaidTools() {
  const { addOperation, updateOperation } = useFeatureStore();
  const [token, setToken] = useState('');
  const [showTokenInput, setShowTokenInput] = useState(true);
  const [isVerifying, setIsVerifying] = useState(false);
  const [isRunning, setIsRunning] = useState(false);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState('');

  const handleVerifyToken = async () => {
    setError('');
    setIsVerifying(true);

    setTimeout(() => {
      setIsVerifying(false);
      if (token.length < 20) {
        setError('Invalid token format');
        return;
      }
      setShowTokenInput(false);
    }, 1500);
  };

  const handleStartRaid = async () => {
    setIsRunning(true);
    setError('');
    setProgress(0);

    const operationId = Math.random().toString(36).substr(2, 9);
    addOperation({
      id: operationId,
      type: 'Server Raid',
      status: 'running',
      progress: 0,
      message: 'Starting server raid...',
      startedAt: new Date(),
    });

    let current = 0;
    const interval = setInterval(() => {
      current += 2;
      setProgress(Math.min(current, 100));

      updateOperation(operationId, {
        progress: Math.min(current, 100),
        message: `Raiding server... ${Math.min(current, 100)}%`,
      });

      if (current >= 100) {
        clearInterval(interval);
        setIsRunning(false);
        updateOperation(operationId, {
          status: 'completed',
          progress: 100,
          message: 'Raid completed',
        });
      }
    }, 100);
  };

  const handleStop = () => {
    setIsRunning(false);
    setProgress(0);
  };

  if (showTokenInput) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-white flex items-center gap-3">
            <Flame className="w-8 h-8 text-red-400" />
            Raid Tools
          </h1>
          <p className="text-slate-400 mt-1">
            Server raiding and spam tools
          </p>
        </div>

        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="text-white">Authentication Required</CardTitle>
            <CardDescription className="text-slate-400">
              Please provide your Discord user token
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {error && (
              <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/20 text-red-400">
                {error}
              </div>
            )}
            <div className="space-y-2">
              <Label htmlFor="token" className="text-slate-300">Discord User Token</Label>
              <Input
                id="token"
                type="password"
                placeholder="Enter your Discord token..."
                value={token}
                onChange={(e) => setToken(e.target.value)}
                className="bg-slate-800/50 border-slate-700 text-white placeholder:text-slate-500"
              />
            </div>
            <Button
              onClick={handleVerifyToken}
              disabled={isVerifying || !token}
              className="bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-400 hover:to-purple-500"
            >
              {isVerifying ? (
                <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Verifying...</>
              ) : (
                'Verify Token'
              )}
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-white flex items-center gap-3">
          <Flame className="w-8 h-8 text-red-400" />
          Raid Tools
        </h1>
        <p className="text-slate-400 mt-1">
          Server raiding and spam tools
        </p>
      </div>

      {/* Warning */}
      <Card className="glass-card border-red-500/30">
        <CardContent className="p-6">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-xl bg-red-500/20 flex items-center justify-center flex-shrink-0">
              <AlertTriangle className="w-6 h-6 text-red-400" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-white">Extreme Warning</h3>
              <p className="text-slate-400 mt-1">
                These tools are for <strong className="text-red-400">educational purposes only</strong>. 
                Using them on servers without permission is illegal and will result in immediate account termination.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Tools */}
      <Tabs defaultValue="raid" className="w-full">
        <TabsList className="bg-slate-800/50">
          <TabsTrigger value="raid" className="data-[state=active]:bg-red-500/20 data-[state=active]:text-red-400">
            <Flame className="w-4 h-4 mr-2" />
            Server Raid
          </TabsTrigger>
          <TabsTrigger value="dmspam" className="data-[state=active]:bg-red-500/20 data-[state=active]:text-red-400">
            <MessageSquare className="w-4 h-4 mr-2" />
            DM Spam
          </TabsTrigger>
          <TabsTrigger value="vcspam" className="data-[state=active]:bg-red-500/20 data-[state=active]:text-red-400">
            <Volume2 className="w-4 h-4 mr-2" />
            VC Spam
          </TabsTrigger>
        </TabsList>

        <TabsContent value="raid" className="mt-4">
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="text-white">Server Raid</CardTitle>
              <CardDescription className="text-slate-400">
                Spam messages in all channels of a server
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="guildId" className="text-slate-300">Server ID</Label>
                <Input
                  id="guildId"
                  placeholder="1234567890123456789"
                  className="bg-slate-800/50 border-slate-700 text-white placeholder:text-slate-500"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="message" className="text-slate-300">Message</Label>
                <Input
                  id="message"
                  placeholder="Enter message to spam..."
                  className="bg-slate-800/50 border-slate-700 text-white placeholder:text-slate-500"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="count" className="text-slate-300">Messages per channel</Label>
                <Input
                  id="count"
                  type="number"
                  defaultValue={10}
                  className="bg-slate-800/50 border-slate-700 text-white placeholder:text-slate-500"
                />
              </div>

              {isRunning && (
                <div className="space-y-2">
                  <Progress value={progress} className="h-3" />
                  <p className="text-slate-500 text-sm text-center">{progress}%</p>
                </div>
              )}

              <div className="flex gap-3">
                {!isRunning ? (
                  <Button onClick={handleStartRaid} variant="destructive">
                    <Play className="mr-2 h-4 w-4" />
                    Start Raid
                  </Button>
                ) : (
                  <Button onClick={handleStop} variant="outline">
                    <Square className="mr-2 h-4 w-4" />
                    Stop
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="dmspam" className="mt-4">
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="text-white">DM Spam</CardTitle>
              <CardDescription className="text-slate-400">
                Spam messages to a specific user
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="userId" className="text-slate-300">User ID</Label>
                <Input
                  id="userId"
                  placeholder="1234567890123456789"
                  className="bg-slate-800/50 border-slate-700 text-white placeholder:text-slate-500"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="dmMessage" className="text-slate-300">Message</Label>
                <Input
                  id="dmMessage"
                  placeholder="Enter message..."
                  className="bg-slate-800/50 border-slate-700 text-white placeholder:text-slate-500"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="dmCount" className="text-slate-300">Count</Label>
                <Input
                  id="dmCount"
                  type="number"
                  defaultValue={10}
                  className="bg-slate-800/50 border-slate-700 text-white placeholder:text-slate-500"
                />
              </div>
              <Button variant="destructive">
                <Play className="mr-2 h-4 w-4" />
                Start DM Spam
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="vcspam" className="mt-4">
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="text-white">VC Spam</CardTitle>
              <CardDescription className="text-slate-400">
                Spam join and leave voice channels
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="vcGuildId" className="text-slate-300">Server ID</Label>
                <Input
                  id="vcGuildId"
                  placeholder="1234567890123456789"
                  className="bg-slate-800/50 border-slate-700 text-white placeholder:text-slate-500"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="vcChannelId" className="text-slate-300">Voice Channel ID</Label>
                <Input
                  id="vcChannelId"
                  placeholder="9876543210987654321"
                  className="bg-slate-800/50 border-slate-700 text-white placeholder:text-slate-500"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="vcDuration" className="text-slate-300">Duration (seconds)</Label>
                <Input
                  id="vcDuration"
                  type="number"
                  defaultValue={60}
                  className="bg-slate-800/50 border-slate-700 text-white placeholder:text-slate-500"
                />
              </div>
              <Button variant="destructive">
                <Volume2 className="mr-2 h-4 w-4" />
                Start VC Spam
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Disclaimer */}
      <div className="p-4 rounded-lg bg-red-500/10 border border-red-500/20">
        <div className="flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-red-400 flex-shrink-0" />
          <p className="text-red-200 text-sm">
            <strong>Legal Notice:</strong> Using these tools to harass, spam, or disrupt 
            Discord servers without permission violates Discord's Terms of Service and may 
            violate local laws. We do not condone illegal use of these tools.
          </p>
        </div>
      </div>
    </div>
  );
}
