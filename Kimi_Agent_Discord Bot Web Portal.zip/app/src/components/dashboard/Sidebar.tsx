import { useState } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useAuthStore } from '@/store/authStore';
import {
  Gamepad2,
  Home,
  Target,
  Copy,
  Users,
  MessageSquare,
  Gift,
  Phone,
  Shield,
  User,
  Zap,
  Flame,
  Settings,
  LogOut,
  ChevronLeft,
  ChevronRight,
  Crown,
  Key,
  CheckCircle,
} from 'lucide-react';

interface SidebarProps {
  isCollapsed: boolean;
  setIsCollapsed: (value: boolean) => void;
}

interface NavItem {
  title: string;
  icon: React.ElementType;
  path: string;
  badge?: string;
  premium?: boolean;
}

const mainNavItems: NavItem[] = [
  { title: 'Dashboard', icon: Home, path: '/dashboard' },
  { title: 'Quest Automation', icon: Target, path: '/dashboard/quest' },
  { title: 'Server Cloner', icon: Copy, path: '/dashboard/clone' },
];

const accountNavItems: NavItem[] = [
  { title: 'Account Stats', icon: User, path: '/dashboard/stats' },
  { title: 'Mass Unfriend', icon: Users, path: '/dashboard/unfriend' },
  { title: 'DM Purge', icon: MessageSquare, path: '/dashboard/purge' },
];

const toolNavItems: NavItem[] = [
  { title: 'Snipers', icon: Gift, path: '/dashboard/snipers', badge: 'HOT' },
  { title: 'Auto Call', icon: Phone, path: '/dashboard/autocall', premium: true },
  { title: 'Token Security', icon: Shield, path: '/dashboard/security' },
  { title: 'Raid Tools', icon: Flame, path: '/dashboard/raid' },
  { title: 'Utilities', icon: Zap, path: '/dashboard/utilities' },
];

const settingsNavItems: NavItem[] = [
  { title: 'Token Generator', icon: Key, path: '/dashboard/token-gen' },
  { title: 'Settings', icon: Settings, path: '/dashboard/settings' },
];

function NavSection({ items, isCollapsed }: { items: NavItem[]; isCollapsed: boolean }) {
  const location = useLocation();
  const { user } = useAuthStore();

  return (
    <div className="space-y-1">
      {items.map((item) => {
        const isActive = location.pathname === item.path;
        const Icon = item.icon;
        const isPremiumLocked = item.premium && !user?.isPremium;

        return (
          <NavLink
            key={item.path}
            to={isPremiumLocked ? '#' : item.path}
            className={cn(
              'flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all duration-200 group relative',
              isActive
                ? 'bg-gradient-to-r from-cyan-500/20 to-purple-500/20 text-cyan-400 border border-cyan-500/30'
                : 'text-slate-400 hover:text-white hover:bg-white/5',
              isPremiumLocked && 'opacity-50 cursor-not-allowed'
            )}
          >
            <Icon className={cn(
              'w-5 h-5 flex-shrink-0 transition-transform duration-200',
              isActive && 'scale-110'
            )} />
            
            {!isCollapsed && (
              <>
                <span className="flex-1 text-sm font-medium">{item.title}</span>
                {item.badge && (
                  <span className="px-2 py-0.5 text-xs bg-gradient-to-r from-red-500 to-pink-500 text-white rounded-full">
                    {item.badge}
                  </span>
                )}
                {item.premium && (
                  <Crown className="w-4 h-4 text-yellow-400" />
                )}
              </>
            )}

            {/* Tooltip for collapsed state */}
            {isCollapsed && (
              <div className="absolute left-full ml-2 px-3 py-2 bg-slate-800 text-white text-sm rounded-lg opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 whitespace-nowrap z-50 border border-slate-700">
                {item.title}
                {item.premium && <span className="ml-2 text-yellow-400">⭐</span>}
              </div>
            )}
          </NavLink>
        );
      })}
    </div>
  );
}

export function Sidebar({ isCollapsed, setIsCollapsed }: SidebarProps) {
  const { user, logout } = useAuthStore();
  const [isLoggingOut, setIsLoggingOut] = useState(false);

  const handleLogout = () => {
    setIsLoggingOut(true);
    setTimeout(() => {
      logout();
      window.location.href = '/';
    }, 500);
  };

  return (
    <div
      className={cn(
        'h-screen bg-slate-900/95 backdrop-blur-xl border-r border-slate-800 flex flex-col transition-all duration-300 fixed left-0 top-0 z-40',
        isCollapsed ? 'w-16' : 'w-64'
      )}
    >
      {/* Logo */}
      <div className="p-4 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-400 to-purple-600 flex items-center justify-center flex-shrink-0">
            <Gamepad2 className="w-5 h-5 text-white" />
          </div>
          {!isCollapsed && (
            <div>
              <h1 className="font-bold text-white text-lg">Kaizen</h1>
              <p className="text-xs text-slate-500">v7.0 Enhanced</p>
            </div>
          )}
        </div>
      </div>

      {/* Collapse Toggle */}
      <button
        onClick={() => setIsCollapsed(!isCollapsed)}
        className="absolute -right-3 top-20 w-6 h-6 bg-slate-800 border border-slate-700 rounded-full flex items-center justify-center text-slate-400 hover:text-white transition-colors"
      >
        {isCollapsed ? <ChevronRight className="w-3 h-3" /> : <ChevronLeft className="w-3 h-3" />}
      </button>

      {/* Token Status */}
      {!isCollapsed && user?.token && (
        <div className="mx-4 mt-4 p-3 rounded-lg bg-green-500/10 border border-green-500/30">
          <div className="flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-green-400" />
            <span className="text-green-400 text-xs font-medium">Discord Connected</span>
          </div>
          <p className="text-slate-500 text-xs mt-1 truncate">
            {user.token.substring(0, 20)}...
          </p>
        </div>
      )}

      {/* Navigation */}
      <ScrollArea className="flex-1 py-4">
        <div className={cn('space-y-6', isCollapsed ? 'px-2' : 'px-4')}>
          {/* Main */}
          {!isCollapsed && (
            <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Main
            </div>
          )}
          <NavSection items={mainNavItems} isCollapsed={isCollapsed} />

          {/* Account */}
          {!isCollapsed && (
            <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider pt-4">
              Account
            </div>
          )}
          {isCollapsed && <div className="pt-4 border-t border-slate-800" />}
          <NavSection items={accountNavItems} isCollapsed={isCollapsed} />

          {/* Tools */}
          {!isCollapsed && (
            <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider pt-4">
              Tools
            </div>
          )}
          {isCollapsed && <div className="pt-4 border-t border-slate-800" />}
          <NavSection items={toolNavItems} isCollapsed={isCollapsed} />

          {/* Settings */}
          {!isCollapsed && (
            <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider pt-4">
              Settings
            </div>
          )}
          {isCollapsed && <div className="pt-4 border-t border-slate-800" />}
          <NavSection items={settingsNavItems} isCollapsed={isCollapsed} />
        </div>
      </ScrollArea>

      {/* User Profile */}
      <div className="p-4 border-t border-slate-800">
        <div className={cn(
          'flex items-center gap-3 p-2 rounded-lg bg-slate-800/50',
          isCollapsed && 'justify-center'
        )}>
          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-cyan-400 to-purple-600 flex items-center justify-center flex-shrink-0">
            <User className="w-4 h-4 text-white" />
          </div>
          {!isCollapsed && (
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-white truncate">{user?.username}</p>
              <p className="text-xs text-slate-500 truncate">{user?.email}</p>
            </div>
          )}
        </div>

        <Button
          variant="ghost"
          onClick={handleLogout}
          disabled={isLoggingOut}
          className={cn(
            'mt-2 w-full text-slate-400 hover:text-red-400 hover:bg-red-500/10 transition-all',
            isCollapsed && 'px-2'
          )}
        >
          <LogOut className="w-4 h-4" />
          {!isCollapsed && <span className="ml-2">Logout</span>}
        </Button>
      </div>
    </div>
  );
}
