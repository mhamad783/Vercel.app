import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { useAuthStore } from '@/store/authStore';
import { useFeatureStore } from '@/store/featureStore';
import {
  Target,
  Copy,
  Gift,
  Phone,
  Shield,
  Zap,
  Crown,
  TrendingUp,
  Activity,
  Clock,
  CheckCircle,
  AlertCircle,
  Loader2,
} from 'lucide-react';

interface StatCardProps {
  title: string;
  value: string | number;
  description?: string;
  icon: React.ElementType;
  trend?: 'up' | 'down' | 'neutral';
  trendValue?: string;
  color: string;
}

function StatCard({ title, value, description, icon: Icon, trend, trendValue, color }: StatCardProps) {
  return (
    <Card className="glass-card hover-glow transition-all duration-300">
      <CardContent className="p-6">
        <div className="flex items-start justify-between">
          <div className="space-y-2">
            <p className="text-sm text-slate-400">{title}</p>
            <p className="text-2xl font-bold text-white">{value}</p>
            {description && <p className="text-xs text-slate-500">{description}</p>}
            {trend && trendValue && (
              <div className={`flex items-center gap-1 text-xs ${
                trend === 'up' ? 'text-green-400' : trend === 'down' ? 'text-red-400' : 'text-slate-400'
              }`}>
                <TrendingUp className="w-3 h-3" />
                {trendValue}
              </div>
            )}
          </div>
          <div className={`w-12 h-12 rounded-xl ${color} flex items-center justify-center`}>
            <Icon className="w-6 h-6 text-white" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

interface FeatureCardProps {
  title: string;
  description: string;
  icon: React.ElementType;
  status: 'active' | 'inactive' | 'running';
  path: string;
  premium?: boolean;
}

function FeatureCard({ title, description, icon: Icon, status, premium }: FeatureCardProps) {
  const { user } = useAuthStore();
  const isPremiumLocked = premium && !user?.isPremium;

  return (
    <Card className={`glass-card transition-all duration-300 group cursor-pointer ${
      isPremiumLocked ? 'opacity-50' : 'hover-glow hover:border-cyan-500/30'
    }`}>
      <CardContent className="p-5">
        <div className="flex items-start gap-4">
          <div className={`w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 ${
            status === 'running' ? 'bg-amber-500/20 animate-pulse' :
            status === 'active' ? 'bg-green-500/20' : 'bg-slate-700/50'
          }`}>
            <Icon className={`w-6 h-6 ${
              status === 'running' ? 'text-amber-400' :
              status === 'active' ? 'text-green-400' : 'text-slate-400'
            }`} />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <h3 className="font-semibold text-white">{title}</h3>
              {premium && <Crown className="w-4 h-4 text-yellow-400" />}
            </div>
            <p className="text-sm text-slate-400 mt-1">{description}</p>
            <div className="flex items-center gap-2 mt-3">
              <Badge variant={status === 'running' ? 'default' : status === 'active' ? 'secondary' : 'outline'}
                className={status === 'running' ? 'bg-amber-500/20 text-amber-400 border-amber-500/30' :
                  status === 'active' ? 'bg-green-500/20 text-green-400 border-green-500/30' :
                  'border-slate-600 text-slate-400'
                }
              >
                {status === 'running' && <Loader2 className="w-3 h-3 mr-1 animate-spin" />}
                {status.charAt(0).toUpperCase() + status.slice(1)}
              </Badge>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export function DashboardOverview() {
  const { user } = useAuthStore();
  const { operations, questRunning, questProgress, giveawaySniper, nitroSniper } = useFeatureStore();
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const activeOperations = operations.filter(op => op.status === 'running');
  const completedOperations = operations.filter(op => op.status === 'completed');

  const features: FeatureCardProps[] = [
    {
      title: 'Quest Automation',
      description: 'Auto-complete video and desktop game quests',
      icon: Target,
      status: questRunning ? 'running' : 'inactive',
      path: '/dashboard/quest',
    },
    {
      title: 'Server Cloner',
      description: 'Clone servers, emojis, and stickers',
      icon: Copy,
      status: 'inactive',
      path: '/dashboard/clone',
    },
    {
      title: 'Giveaway Sniper',
      description: 'Auto-enter giveaways with smart detection',
      icon: Gift,
      status: giveawaySniper ? 'active' : 'inactive',
      path: '/dashboard/snipers',
    },
    {
      title: 'Nitro Sniper',
      description: 'Auto-claim Discord Nitro codes',
      icon: Zap,
      status: nitroSniper ? 'running' : 'inactive',
      path: '/dashboard/snipers',
      premium: true,
    },
    {
      title: 'Auto Call',
      description: 'Scheduled voice calls and mass calling',
      icon: Phone,
      status: 'inactive',
      path: '/dashboard/autocall',
      premium: true,
    },
    {
      title: 'Token Security',
      description: 'Monitor and protect your tokens',
      icon: Shield,
      status: 'inactive',
      path: '/dashboard/security',
    },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-white">
            Welcome back, <span className="gradient-text">{user?.username}</span>
          </h1>
          <p className="text-slate-400 mt-1">
            Here's what's happening with your account today
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div className="text-right">
            <p className="text-sm text-slate-400">{currentTime.toLocaleDateString()}</p>
            <p className="text-lg font-mono text-cyan-400">{currentTime.toLocaleTimeString()}</p>
          </div>
          {user?.isPremium ? (
            <Badge className="bg-gradient-to-r from-yellow-500 to-amber-500 text-white border-0 px-3 py-1">
              <Crown className="w-4 h-4 mr-1" />
              Premium
            </Badge>
          ) : (
            <Badge variant="outline" className="border-cyan-500/30 text-cyan-400">
              Free Plan
            </Badge>
          )}
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Active Operations"
          value={activeOperations.length}
          description="Currently running tasks"
          icon={Activity}
          color="bg-gradient-to-br from-cyan-500 to-cyan-600"
        />
        <StatCard
          title="Completed Tasks"
          value={completedOperations.length}
          description="Total successful operations"
          icon={CheckCircle}
          trend="up"
          trendValue="+12% this week"
          color="bg-gradient-to-br from-green-500 to-green-600"
        />
        <StatCard
          title="Quest Progress"
          value={`${questProgress}%`}
          description={questRunning ? 'Quest automation running' : 'No active quests'}
          icon={Target}
          color="bg-gradient-to-br from-purple-500 to-purple-600"
        />
        <StatCard
          title="Clone Usage"
          value={user?.isPremium ? 'Unlimited' : '3/3'}
          description={user?.isPremium ? 'Premium benefits active' : 'Free tier limit'}
          icon={Copy}
          color="bg-gradient-to-br from-pink-500 to-pink-600"
        />
      </div>

      {/* Active Operations */}
      {activeOperations.length > 0 && (
        <Card className="glass-card border-amber-500/30">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Activity className="w-5 h-5 text-amber-400" />
              Active Operations
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {activeOperations.map((op) => (
              <div key={op.id} className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Loader2 className="w-4 h-4 text-amber-400 animate-spin" />
                    <span className="text-white font-medium">{op.type}</span>
                  </div>
                  <span className="text-sm text-slate-400">{op.progress}%</span>
                </div>
                <Progress value={op.progress} className="h-2" />
                <p className="text-sm text-slate-500">{op.message}</p>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Features Grid */}
      <div>
        <h2 className="text-xl font-semibold text-white mb-4">Quick Access</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {features.map((feature) => (
            <FeatureCard key={feature.title} {...feature} />
          ))}
        </div>
      </div>

      {/* Recent Activity */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Clock className="w-5 h-5 text-cyan-400" />
            Recent Activity
          </CardTitle>
        </CardHeader>
        <CardContent>
          {operations.length === 0 ? (
            <div className="text-center py-8">
              <AlertCircle className="w-12 h-12 text-slate-600 mx-auto mb-3" />
              <p className="text-slate-500">No recent activity</p>
              <p className="text-sm text-slate-600 mt-1">Start using features to see activity here</p>
            </div>
          ) : (
            <div className="space-y-3">
              {[...operations].reverse().slice(0, 5).map((op) => (
                <div key={op.id} className="flex items-center gap-3 p-3 rounded-lg bg-slate-800/50">
                  <div className={`w-2 h-2 rounded-full ${
                    op.status === 'completed' ? 'bg-green-400' :
                    op.status === 'running' ? 'bg-amber-400 animate-pulse' :
                    op.status === 'error' ? 'bg-red-400' : 'bg-slate-400'
                  }`} />
                  <div className="flex-1">
                    <p className="text-white text-sm">{op.type}</p>
                    <p className="text-slate-500 text-xs">{op.message}</p>
                  </div>
                  <span className="text-slate-600 text-xs">
                    {new Date(op.startedAt).toLocaleTimeString()}
                  </span>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
