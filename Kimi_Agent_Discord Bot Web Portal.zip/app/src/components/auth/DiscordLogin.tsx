import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { InputOTP, InputOTPGroup, InputOTPSlot } from '@/components/ui/input-otp';
import { useAuthStore } from '@/store/authStore';
import { Loader2, Shield, Lock, Mail, Key, AlertTriangle, CheckCircle, Eye, EyeOff } from 'lucide-react';

export function DiscordLogin() {
  const navigate = useNavigate();
  const { login } = useAuthStore();
  
  const [step, setStep] = useState<'credentials' | '2fa' | 'token'>('credentials');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [twoFactorCode, setTwoFactorCode] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [generatedToken, setGeneratedToken] = useState('');
  const [showToken, setShowToken] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleCredentialsSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    // Simulate Discord API authentication
    setTimeout(() => {
      setIsLoading(false);
      
      // Basic validation
      if (!email.includes('@') || password.length < 6) {
        setError('Invalid Discord credentials');
        return;
      }

      // Check if account likely has 2FA (simulate)
      const has2FA = true; // In real implementation, this would come from Discord API
      
      if (has2FA) {
        setStep('2fa');
      } else {
        generateToken();
      }
    }, 2000);
  };

  const handle2FASubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    // Simulate 2FA verification with Discord
    setTimeout(() => {
      setIsLoading(false);

      if (twoFactorCode.length !== 6) {
        setError('Please enter a valid 6-digit code');
        return;
      }

      generateToken();
    }, 1500);
  };

  const generateToken = () => {
    // Simulate token extraction from Discord login
    // In a real implementation, this would be extracted from the Discord API response
    const mockToken = `${btoa(email.split('@')[0]).replace(/=/g, '')}.${Math.random().toString(36).substring(2, 15)}.${Math.random().toString(36).substring(2, 15)}`;
    
    setGeneratedToken(mockToken);
    setStep('token');

    // Auto-login to dashboard with the token
    const mockUser = {
      id: Math.random().toString(36).substr(2, 9),
      username: email.split('@')[0],
      email: email,
      isPremium: false,
      mfaEnabled: true,
      token: mockToken,
    };

    login(mockUser);
  };

  const handleCopyToken = () => {
    navigator.clipboard.writeText(generatedToken);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleContinueToDashboard = () => {
    navigate('/dashboard');
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-slate-900 to-slate-800" />
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl" />
      <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl" />
      
      {/* Animated Grid */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute inset-0" style={{
          backgroundImage: 'linear-gradient(rgba(6, 182, 212, 0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(6, 182, 212, 0.1) 1px, transparent 1px)',
          backgroundSize: '50px 50px'
        }} />
      </div>

      <Card className="w-full max-w-md relative z-10 glass-card glow-cyan">
        <CardHeader className="space-y-4 text-center">
          <div className="mx-auto w-16 h-16 rounded-xl bg-gradient-to-br from-[#5865F2] to-[#4752C4] flex items-center justify-center">
            <svg className="w-10 h-10 text-white" viewBox="0 0 24 24" fill="currentColor">
              <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028 14.09 14.09 0 0 0 1.226-1.994.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z"/>
            </svg>
          </div>
          <div>
            <CardTitle className="text-2xl font-bold text-white">
              {step === 'token' ? 'Login Successful!' : 'Login to Discord'}
            </CardTitle>
            <CardDescription className="text-slate-400 mt-2">
              {step === 'credentials' && 'Enter your Discord credentials to login'}
              {step === '2fa' && 'Enter your 2FA code from your authenticator app'}
              {step === 'token' && 'Your token has been extracted and saved'}
            </CardDescription>
          </div>
        </CardHeader>

        <CardContent className="space-y-6">
          {/* Warning */}
          <Alert className="bg-amber-500/10 border-amber-500/20">
            <AlertTriangle className="w-5 h-5 text-amber-400" />
            <AlertDescription className="text-amber-200 text-sm">
              <strong>Warning:</strong> This uses selfbot technology which violates Discord's ToS. 
              Use an alt account to avoid bans.
            </AlertDescription>
          </Alert>

          {error && (
            <Alert variant="destructive" className="bg-red-500/10 border-red-500/20">
              <AlertDescription className="text-red-400">{error}</AlertDescription>
            </Alert>
          )}

          {step === 'credentials' && (
            <form onSubmit={handleCredentialsSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email" className="text-slate-300 flex items-center gap-2">
                  <Mail className="w-4 h-4" />
                  Discord Email
                </Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="you@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="bg-slate-800/50 border-slate-700 text-white placeholder:text-slate-500 focus:border-[#5865F2] focus:ring-[#5865F2]/20"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="password" className="text-slate-300 flex items-center gap-2">
                  <Lock className="w-4 h-4" />
                  Discord Password
                </Label>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPassword ? 'text' : 'password'}
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="bg-slate-800/50 border-slate-700 text-white placeholder:text-slate-500 focus:border-[#5865F2] focus:ring-[#5865F2]/20 pr-10"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <Button
                type="submit"
                disabled={isLoading}
                className="w-full bg-[#5865F2] hover:bg-[#4752C4] text-white font-semibold py-6 transition-all duration-300"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Logging in to Discord...
                  </>
                ) : (
                  'Login to Discord'
                )}
              </Button>
            </form>
          )}

          {step === '2fa' && (
            <form onSubmit={handle2FASubmit} className="space-y-6">
              <div className="flex justify-center">
                <div className="w-16 h-16 rounded-full bg-[#5865F2]/20 flex items-center justify-center">
                  <Shield className="w-8 h-8 text-[#5865F2]" />
                </div>
              </div>

              <div className="text-center space-y-2">
                <p className="text-slate-300">Two-Factor Authentication Required</p>
                <p className="text-sm text-slate-500">
                  Enter the 6-digit code from your authenticator app
                </p>
              </div>

              <div className="flex justify-center">
                <InputOTP
                  maxLength={6}
                  value={twoFactorCode}
                  onChange={setTwoFactorCode}
                  className="gap-2"
                >
                  <InputOTPGroup>
                    <InputOTPSlot 
                      index={0} 
                      className="w-12 h-14 bg-slate-800/50 border-slate-700 text-white text-xl focus:border-[#5865F2] focus:ring-[#5865F2]/20"
                    />
                    <InputOTPSlot 
                      index={1}
                      className="w-12 h-14 bg-slate-800/50 border-slate-700 text-white text-xl focus:border-[#5865F2] focus:ring-[#5865F2]/20"
                    />
                    <InputOTPSlot 
                      index={2}
                      className="w-12 h-14 bg-slate-800/50 border-slate-700 text-white text-xl focus:border-[#5865F2] focus:ring-[#5865F2]/20"
                    />
                    <InputOTPSlot 
                      index={3}
                      className="w-12 h-14 bg-slate-800/50 border-slate-700 text-white text-xl focus:border-[#5865F2] focus:ring-[#5865F2]/20"
                    />
                    <InputOTPSlot 
                      index={4}
                      className="w-12 h-14 bg-slate-800/50 border-slate-700 text-white text-xl focus:border-[#5865F2] focus:ring-[#5865F2]/20"
                    />
                    <InputOTPSlot 
                      index={5}
                      className="w-12 h-14 bg-slate-800/50 border-slate-700 text-white text-xl focus:border-[#5865F2] focus:ring-[#5865F2]/20"
                    />
                  </InputOTPGroup>
                </InputOTP>
              </div>

              <Button
                type="submit"
                disabled={isLoading || twoFactorCode.length !== 6}
                className="w-full bg-[#5865F2] hover:bg-[#4752C4] text-white font-semibold py-6 transition-all duration-300"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Verifying...
                  </>
                ) : (
                  'Verify & Continue'
                )}
              </Button>

              <Button
                type="button"
                variant="ghost"
                onClick={() => setStep('credentials')}
                className="w-full text-slate-400 hover:text-white"
              >
                Back
              </Button>
            </form>
          )}

          {step === 'token' && (
            <div className="space-y-6">
              <div className="flex justify-center">
                <div className="w-16 h-16 rounded-full bg-green-500/20 flex items-center justify-center">
                  <CheckCircle className="w-8 h-8 text-green-400" />
                </div>
              </div>

              <div className="text-center space-y-2">
                <p className="text-white font-medium">Successfully logged into Discord!</p>
                <p className="text-slate-400 text-sm">
                  Your token has been extracted and saved for use with all features.
                </p>
              </div>

              {/* Token Display */}
              <div className="space-y-2">
                <Label className="text-slate-300 flex items-center gap-2">
                  <Key className="w-4 h-4" />
                  Your Discord Token (Auto-saved)
                </Label>
                <div className="relative">
                  <Input
                    type={showToken ? 'text' : 'password'}
                    value={generatedToken}
                    readOnly
                    className="bg-slate-800/50 border-slate-700 text-white font-mono text-sm pr-24"
                  />
                  <div className="absolute right-2 top-1/2 -translate-y-1/2 flex gap-1">
                    <button
                      onClick={() => setShowToken(!showToken)}
                      className="p-1.5 rounded hover:bg-slate-700 text-slate-400 hover:text-white"
                    >
                      {showToken ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                    <button
                      onClick={handleCopyToken}
                      className="p-1.5 rounded hover:bg-slate-700 text-slate-400 hover:text-white"
                    >
                      {copied ? <CheckCircle className="w-4 h-4 text-green-400" /> : <Key className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
              </div>

              <div className="p-3 rounded-lg bg-green-500/10 border border-green-500/20">
                <p className="text-green-200 text-sm text-center">
                  <CheckCircle className="w-4 h-4 inline mr-1" />
                  Token automatically saved to your account
                </p>
              </div>

              <Button
                onClick={handleContinueToDashboard}
                className="w-full bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-400 hover:to-purple-500 text-white font-semibold py-6"
              >
                Continue to Dashboard
              </Button>

              <p className="text-center text-xs text-slate-500">
                You can now use all features without entering your token again
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Footer */}
      <div className="absolute bottom-4 left-0 right-0 text-center">
        <p className="text-slate-600 text-sm">
          Created by <span className="text-cyan-400 font-semibold">kaizen</span>
        </p>
      </div>
    </div>
  );
}
