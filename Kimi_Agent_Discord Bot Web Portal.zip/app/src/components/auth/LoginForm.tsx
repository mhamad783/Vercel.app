import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useAuthStore } from '@/store/authStore';
import { Loader2, Key, ArrowLeft, CheckCircle, Eye, EyeOff } from 'lucide-react';

export function LoginForm() {
  const navigate = useNavigate();
  const { login } = useAuthStore();
  
  const [token, setToken] = useState('');
  const [showToken, setShowToken] = useState(false);
  const [isVerifying, setIsVerifying] = useState(false);
  const [error, setError] = useState('');

  const handleTokenSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsVerifying(true);

    // Simulate token verification
    setTimeout(() => {
      setIsVerifying(false);
      
      if (token.length < 20) {
        setError('Invalid Discord token format. Tokens should be 50+ characters long.');
        return;
      }

      // Simulate successful login with token
      const mockUser = {
        id: Math.random().toString(36).substr(2, 9),
        username: 'DiscordUser',
        email: 'user@discord.com',
        isPremium: false,
        mfaEnabled: false,
        token: token,
      };

      login(mockUser);
      navigate('/dashboard');
    }, 1500);
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-slate-900 to-slate-800" />
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl" />
      <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl" />
      
      {/* Animated Grid */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute inset-0" style={{
          backgroundImage: 'linear-gradient(rgba(6, 182, 212, 0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(6, 182, 212, 0.1) 1px, transparent 1px)',
          backgroundSize: '50px 50px'
        }} />
      </div>

      <Card className="w-full max-w-md relative z-10 glass-card glow-cyan">
        <CardHeader className="space-y-4 text-center">
          <Button
            variant="ghost"
            onClick={() => navigate('/')}
            className="absolute left-4 top-4 text-slate-400 hover:text-white"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div className="mx-auto w-16 h-16 rounded-xl bg-gradient-to-br from-cyan-400 to-purple-600 flex items-center justify-center">
            <Key className="w-8 h-8 text-white" />
          </div>
          <div>
            <CardTitle className="text-3xl font-bold gradient-text">
              Login with Token
            </CardTitle>
            <CardDescription className="text-slate-400 mt-2">
              Enter your Discord user token to access the dashboard
            </CardDescription>
          </div>
        </CardHeader>

        <CardContent className="space-y-6">
          {error && (
            <Alert variant="destructive" className="bg-red-500/10 border-red-500/20">
              <AlertDescription className="text-red-400">{error}</AlertDescription>
            </Alert>
          )}

          <form onSubmit={handleTokenSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="token" className="text-slate-300 flex items-center gap-2">
                <Key className="w-4 h-4" />
                Discord User Token
              </Label>
              <div className="relative">
                <Input
                  id="token"
                  type={showToken ? 'text' : 'password'}
                  placeholder="Enter your Discord token..."
                  value={token}
                  onChange={(e) => setToken(e.target.value)}
                  className="bg-slate-800/50 border-slate-700 text-white placeholder:text-slate-500 focus:border-cyan-500 focus:ring-cyan-500/20 pr-10"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowToken(!showToken)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                >
                  {showToken ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
              <p className="text-xs text-slate-500">
                Your token is securely encrypted and never stored on our servers.
              </p>
            </div>

            <Button
              type="submit"
              disabled={isVerifying}
              className="w-full bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-400 hover:to-purple-500 text-white font-semibold py-6 transition-all duration-300 hover-glow"
            >
              {isVerifying ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Verifying Token...
                </>
              ) : (
                <>
                  <CheckCircle className="mr-2 h-4 w-4" />
                  Login with Token
                </>
              )}
            </Button>
          </form>

          <div className="p-4 rounded-lg bg-slate-800/50 space-y-2">
            <p className="text-slate-300 font-medium text-sm">How to get your token:</p>
            <ol className="text-slate-500 text-xs space-y-1 list-decimal list-inside">
              <li>Open Discord in your browser</li>
              <li>Press F12 to open Developer Tools</li>
              <li>Go to Application → Local Storage</li>
              <li>Find the token key and copy the value</li>
            </ol>
          </div>

          <div className="text-center">
            <Button
              variant="link"
              onClick={() => navigate('/login/discord')}
              className="text-cyan-400 hover:text-cyan-300"
            >
              Prefer to login with Discord credentials instead?
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Footer */}
      <div className="absolute bottom-4 left-0 right-0 text-center">
        <p className="text-slate-600 text-sm">
          Created by <span className="text-cyan-400 font-semibold">kaizen</span>
        </p>
      </div>
    </div>
  );
}
